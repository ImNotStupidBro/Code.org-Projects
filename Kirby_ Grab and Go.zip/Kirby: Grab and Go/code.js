

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["b4572bdc-b30c-453b-9ed3-9e16e9c0a559","1e1f0f61-c4fc-43d8-9cb2-fcfd77ef446c","8d1eb85e-7ab5-4315-ae8c-38daf1149b2d","6fca1689-b3ef-49c2-8d09-d0fe137a0ad6","a5dfe4d3-4f8b-4216-926f-abbbbd31c661","afbbd701-9164-4dde-abdf-85bd4be00b8d","acac8933-eb7d-4024-8a50-296de8ad030f","6b2f1559-ffa7-493c-a823-2ba31fb1bd5a","1c0ecc63-3c4b-4f58-b837-cdb3aae96c84","d1e39711-415e-4aa1-8945-79b1636e69a0","6a1602d8-65d9-4a63-ad3f-9daa3888a4de","8afc2300-f52f-4c08-a769-5b5de8b92e9f","ab487a53-b4fe-41b1-8f1f-bc5bc571c10a","9c34c6ea-086d-4154-bc68-477447dbbf6d","b9c0829d-69db-42fa-84dd-9b056bfe11c9","45d45379-0855-4a84-b9f2-c791aa1e4de6","2e406c29-028f-4ac9-9b0a-c9bd49935047","a7b980a9-15f6-4bb1-8289-24e12cfddfd8","a6d4a0ff-c863-40e5-b3b6-9fad6bc549c4","c4884ec5-816c-4523-ab67-f8c39f0a8b86","16e59fe7-796c-4c65-a38c-67903175ab66","078310ed-7f68-4ca4-96f2-811e7ee1be59","c677b3e6-ca5d-4eb9-aa93-903ad93bcc24","0b5bf9a5-9a90-4fe6-a848-8aa0a6359385"],"propsByKey":{"b4572bdc-b30c-453b-9ed3-9e16e9c0a559":{"name":"kirbysDreamLand","sourceUrl":null,"frameSize":{"x":405,"y":399},"frameCount":1,"looping":true,"frameDelay":12,"version":"NA0_PokxVCT11G_.fbHQWvJB2JXpNgOv","loadedFromSource":true,"saved":true,"sourceSize":{"x":405,"y":399},"rootRelativePath":"assets/b4572bdc-b30c-453b-9ed3-9e16e9c0a559.png"},"1e1f0f61-c4fc-43d8-9cb2-fcfd77ef446c":{"name":"kirbyWalking","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":4,"looping":true,"frameDelay":4,"version":"h9pko_YouYo38BFV1lMh6dTwqSs60hG2","loadedFromSource":true,"saved":true,"sourceSize":{"x":160,"y":160},"rootRelativePath":"assets/1e1f0f61-c4fc-43d8-9cb2-fcfd77ef446c.png"},"8d1eb85e-7ab5-4315-ae8c-38daf1149b2d":{"name":"kirbyJumping","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"y7blS2QiwnBEOGWKBoazLw3_YzlpuyIQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/8d1eb85e-7ab5-4315-ae8c-38daf1149b2d.png"},"6fca1689-b3ef-49c2-8d09-d0fe137a0ad6":{"name":"kirbyFalling","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"nxRzyiO0qsyWIjmrgIzEf..b3zRWeHV0","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/6fca1689-b3ef-49c2-8d09-d0fe137a0ad6.png"},"a5dfe4d3-4f8b-4216-926f-abbbbd31c661":{"name":"kirbyFloating","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":2,"looping":true,"frameDelay":5,"version":"zyFAKK1qGetQPWOwDPf..F.WDxA.ajGK","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":262},"rootRelativePath":"assets/a5dfe4d3-4f8b-4216-926f-abbbbd31c661.png"},"afbbd701-9164-4dde-abdf-85bd4be00b8d":{"name":"kirbyFlapping1","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"BUTe27eAtiqgMrR5.bzwq_UsKEPWGV32","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":131},"rootRelativePath":"assets/afbbd701-9164-4dde-abdf-85bd4be00b8d.png"},"acac8933-eb7d-4024-8a50-296de8ad030f":{"name":"kirbyFlapping2","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"x3dGmlQi5SMjoZjvd1TFQvbIjMOHDiU2","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":131},"rootRelativePath":"assets/acac8933-eb7d-4024-8a50-296de8ad030f.png"},"6b2f1559-ffa7-493c-a823-2ba31fb1bd5a":{"name":"waddleDeeL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":2,"looping":true,"frameDelay":12,"version":"7Vcal0Y014cD7CcxmwoH5WmLeHpbwJSo","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":160},"rootRelativePath":"assets/6b2f1559-ffa7-493c-a823-2ba31fb1bd5a.png"},"1c0ecc63-3c4b-4f58-b837-cdb3aae96c84":{"name":"scarfyL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":2,"looping":true,"frameDelay":10,"version":"Ib7KrIfGsj2InSkk6vxVWx_dL36zdNNw","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":160},"rootRelativePath":"assets/1c0ecc63-3c4b-4f58-b837-cdb3aae96c84.png"},"d1e39711-415e-4aa1-8945-79b1636e69a0":{"name":"scarfyR","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":2,"looping":true,"frameDelay":12,"version":"OMnDCIS_zWN83R72Q.WRWvk2VfGQW8Zv","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":160},"rootRelativePath":"assets/d1e39711-415e-4aa1-8945-79b1636e69a0.png"},"6a1602d8-65d9-4a63-ad3f-9daa3888a4de":{"name":"twizzyL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":2,"looping":true,"frameDelay":5,"version":"yCq104CVJGtpHXfGTDhwZksvAGy7Vq_5","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":160},"rootRelativePath":"assets/6a1602d8-65d9-4a63-ad3f-9daa3888a4de.png"},"8afc2300-f52f-4c08-a769-5b5de8b92e9f":{"name":"brontoBurtL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":2,"looping":true,"frameDelay":5,"version":"k4gqX1AzI6.J9C.MALF7hLxHhAOj8E2k","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":160},"rootRelativePath":"assets/8afc2300-f52f-4c08-a769-5b5de8b92e9f.png"},"ab487a53-b4fe-41b1-8f1f-bc5bc571c10a":{"name":"brontoBurtR","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":2,"looping":true,"frameDelay":5,"version":"pnX.qPUpKaUHKAAtFW6p_0zdZqwKuNxf","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":160},"rootRelativePath":"assets/ab487a53-b4fe-41b1-8f1f-bc5bc571c10a.png"},"9c34c6ea-086d-4154-bc68-477447dbbf6d":{"name":"maximumTomato","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/9c34c6ea-086d-4154-bc68-477447dbbf6d.png","frameSize":{"x":64,"y":68},"frameCount":1,"looping":true,"frameDelay":4,"version":"Rq5kPVJuxR2oddLWle2jYQy4Yl2hFQNZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":68},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/9c34c6ea-086d-4154-bc68-477447dbbf6d.png"},"b9c0829d-69db-42fa-84dd-9b056bfe11c9":{"name":"bread","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/b9c0829d-69db-42fa-84dd-9b056bfe11c9.png","frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"jQ.5KDbkpqizWk9qYwrl1fMYE0ozes4g","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/b9c0829d-69db-42fa-84dd-9b056bfe11c9.png"},"45d45379-0855-4a84-b9f2-c791aa1e4de6":{"name":"burger","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/45d45379-0855-4a84-b9f2-c791aa1e4de6.png","frameSize":{"x":64,"y":73},"frameCount":1,"looping":true,"frameDelay":4,"version":"_UmfRC0.RKp8thFHH3kiALzuRLI_EsYV","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":73},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/45d45379-0855-4a84-b9f2-c791aa1e4de6.png"},"2e406c29-028f-4ac9-9b0a-c9bd49935047":{"name":"candy","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/2e406c29-028f-4ac9-9b0a-c9bd49935047.png","frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"BrHQJo5XJgyrX0BFqqzH7BoF.mMozwzS","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/2e406c29-028f-4ac9-9b0a-c9bd49935047.png"},"a7b980a9-15f6-4bb1-8289-24e12cfddfd8":{"name":"cookie","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/a7b980a9-15f6-4bb1-8289-24e12cfddfd8.png","frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"K0E_V2r51o9Wo_9vK9G38qVUojvirSwM","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/a7b980a9-15f6-4bb1-8289-24e12cfddfd8.png"},"a6d4a0ff-c863-40e5-b3b6-9fad6bc549c4":{"name":"flan","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/a6d4a0ff-c863-40e5-b3b6-9fad6bc549c4.png","frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"eOlHuUv8dVj8aSgrY7zzlRm_HBtJT.nQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/a6d4a0ff-c863-40e5-b3b6-9fad6bc549c4.png"},"c4884ec5-816c-4523-ab67-f8c39f0a8b86":{"name":"tomato","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/c4884ec5-816c-4523-ab67-f8c39f0a8b86.png","frameSize":{"x":64,"y":60},"frameCount":1,"looping":true,"frameDelay":4,"version":"zZGryybck6NAv_LhkDS1Yo9p3tDp7wG0","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":60},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/c4884ec5-816c-4523-ab67-f8c39f0a8b86.png"},"16e59fe7-796c-4c65-a38c-67903175ab66":{"name":"healthPoint","sourceUrl":null,"frameSize":{"x":26,"y":46},"frameCount":1,"looping":true,"frameDelay":12,"version":"ilUn2eexVjO6ykFg.PhOZM8UlQ3yf7Hk","loadedFromSource":true,"saved":true,"sourceSize":{"x":26,"y":46},"rootRelativePath":"assets/16e59fe7-796c-4c65-a38c-67903175ab66.png"},"078310ed-7f68-4ca4-96f2-811e7ee1be59":{"name":"emptyhealthPoint","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/078310ed-7f68-4ca4-96f2-811e7ee1be59.png","frameSize":{"x":26,"y":46},"frameCount":1,"looping":true,"frameDelay":4,"version":"Yhxw.MOiP4yAlgdkwrJQo5VAZQcivYne","loadedFromSource":true,"saved":true,"sourceSize":{"x":26,"y":46},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/078310ed-7f68-4ca4-96f2-811e7ee1be59.png"},"c677b3e6-ca5d-4eb9-aa93-903ad93bcc24":{"name":"gameoverscreen","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/c677b3e6-ca5d-4eb9-aa93-903ad93bcc24.png","frameSize":{"x":400,"y":419},"frameCount":1,"looping":true,"frameDelay":4,"version":"MhRAFYw4x0uH48CC1sNo4vFmxMxXTkYn","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":419},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/c677b3e6-ca5d-4eb9-aa93-903ad93bcc24.png"},"0b5bf9a5-9a90-4fe6-a848-8aa0a6359385":{"name":"HUDSprite","sourceUrl":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/0b5bf9a5-9a90-4fe6-a848-8aa0a6359385.png","frameSize":{"x":400,"y":101},"frameCount":1,"looping":true,"frameDelay":4,"version":"sdKNl.kLCZ4UMapO9KId4FjPd.Q9T6lt","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":101},"rootRelativePath":"assets/v3/animations/jOwLrWpajVFr2-ilLPzRZ1nEUx9IVr8Nrd8k6ffLy3k/0b5bf9a5-9a90-4fe6-a848-8aa0a6359385.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//GAME SETUP
// Create the sprites
var background1 = createSprite(200,200);
background1.setAnimation("kirbysDreamLand");
background1.setCollider("rectangle", 0,355,400,500,0);
var background2 = createSprite(600,200);
background2.setAnimation("kirbysDreamLand");
background2.setCollider("rectangle", 0,355,400,500,0);
var background3 = createSprite(1000,200);
background3.setAnimation("kirbysDreamLand");
background3.setCollider("rectangle", 0,355,400,500,0);

var kirby = createSprite(200,265);
kirby.setAnimation("kirbyWalking");
kirby.setCollider("rectangle");

var enemy1 = createSprite(800,265);
enemy1.setAnimation("waddleDeeL");
enemy1.setCollider("circle");
var enemy2 = createSprite(800,125);
enemy2.setAnimation("scarfyL");
enemy2.setCollider("circle");
var enemy3 = createSprite(800,125);
enemy3.setAnimation("twizzyL");
enemy3.setCollider("circle");
var enemy4 = createSprite(800,kirby.y);
enemy4.setAnimation("brontoBurtL");
enemy4.setCollider("circle");

var food1 = createSprite(2500, 85);
food1.setAnimation("maximumTomato");
var food2 = createSprite(500, randomNumber(100,255));
food2.setAnimation("tomato");
var food3 = createSprite(850, randomNumber(100,255));
food3.setAnimation("flan");
var food4 = createSprite(1200, randomNumber(100,255));
food4.setAnimation("cookie");
var food5 = createSprite(1550, randomNumber(100,255));
food5.setAnimation("bread");
food5.setCollider("rectangle", 0,0,50,70,-45);
var food6 = createSprite(1900, randomNumber(100,255));
food6.setAnimation("burger");
var food7 = createSprite(2250, randomNumber(100,255));
food7.setAnimation("candy");
food7.setCollider("rectangle", 0,0,55,64,-45);

var HUD = createSprite(200,359);
HUD.setAnimation("HUDSprite");
var healthPoint1 = createSprite(210,333);
healthPoint1.setAnimation("healthPoint");
var healthPoint2 = createSprite(235,333);
healthPoint2.setAnimation("healthPoint");
var healthPoint3 = createSprite(260,333);
healthPoint3.setAnimation("healthPoint");
var healthPoint4 = createSprite(285,333);
healthPoint4.setAnimation("healthPoint");
var healthPoint5 = createSprite(310,333);
healthPoint5.setAnimation("healthPoint");
var healthPoint6 = createSprite(335,333);
healthPoint6.setAnimation("healthPoint");

var GameOverScreen = createSprite(200,200);
GameOverScreen.setAnimation("gameoverscreen");
GameOverScreen.visible = false;

// set velocity for the obstacle and the target
background1.velocityX = -2;
background2.velocityX = -2;
background3.velocityX = -2;
enemy1.velocityX = -5;
enemy2.velocityX = 0;
enemy3.velocityX = 0;
enemy4.velocityX = -4;
food1.velocityX = -20;
food2.velocityX = -3;
food3.velocityX = -3;
food4.velocityX = -3;
food5.velocityX = -3;
food6.velocityX = -3;
food7.velocityX = -3;

//create the variables
var score = 0;
var health = 6;
var NumberOfIFrames = 100;

function Walk() {
  kirby.setAnimation("kirbyWalking");
  kirby.velocityY = 0;
  kirby.y = 265;
}
function Jump() {
  kirby.velocityY = -11;
  kirby.setAnimation("kirbyJumping");
}
function Fall() {
  kirby.velocityY = kirby.velocityY + 0.4;
}
function Float() {
  kirby.setAnimation("kirbyFloating");
  kirby.velocityY = -10;
}
function TakeDamage() {
  if (enemy1.isTouching(kirby) && NumberOfIFrames <= 0) {
    health = health - 1;
    enemy1.x = randomNumber(700,900);
    NumberOfIFrames = 200;
    playSound("assets/category_hits/retro_game_simple_impact_3.mp3", false);
  } else if (enemy1.isTouching(kirby) && NumberOfIFrames > 0) {
    enemy1.x = randomNumber(700,900);
  }
  if (enemy2.isTouching(kirby) && NumberOfIFrames <= 0) {
    health = health - 1;
    enemy2.x = randomNumber(700,900);
    enemy2.setAnimation("scarfyL");
    NumberOfIFrames = 200;
    playSound("assets/category_hits/retro_game_simple_impact_3.mp3", false);
  } else if (enemy2.isTouching(kirby) && NumberOfIFrames > 0) {
    enemy2.x = randomNumber(700,900);
    enemy2.setAnimation("scarfyL");
  }
  if (enemy3.isTouching(kirby) && NumberOfIFrames <= 0) {
    health = health - 1;
    enemy3.x = randomNumber(700,900);
    NumberOfIFrames = 200;
    playSound("assets/category_hits/retro_game_simple_impact_3.mp3", false);
  } else if (enemy3.isTouching(kirby) && NumberOfIFrames > 0) {
    enemy3.x = randomNumber(700,900);
  }
  if (enemy4.isTouching(kirby) && NumberOfIFrames <= 0) {
    health = health - 1;
    enemy4.x = 1000;
    enemy4.y = kirby.y;
    enemy4.setAnimation("brontoBurtL");
    enemy4.velocityX = -4;
    NumberOfIFrames = 200;
    playSound("assets/category_hits/retro_game_simple_impact_3.mp3", false);
  } else if (enemy4.isTouching(kirby) && NumberOfIFrames > 0) {
    enemy4.x = 1000;
    enemy4.y = kirby.y;
    enemy4.setAnimation("brontoBurtL");
    enemy4.velocityX = -4;
  }
}
function IncreaseDifficulty() {
  if (score >= 20) {
    enemy2.velocityX = -2;
  }
  if (score >= 50) {
    enemy3.velocityX = -7;
  }
}
function LoseHealth() {
  if (health <= 5) {
    healthPoint6.setAnimation("emptyhealthPoint");
  } else if (health >= 6) {
    healthPoint6.setAnimation("healthPoint");
  }
  if (health <= 4) {
    healthPoint5.setAnimation("emptyhealthPoint");
  } else if (health >= 5) {
    healthPoint5.setAnimation("healthPoint");
  }
  if (health <= 3) {
    healthPoint4.setAnimation("emptyhealthPoint");
  } else if (health >= 4) {
    healthPoint4.setAnimation("healthPoint");
  }
  if (health <= 2) {
    healthPoint3.setAnimation("emptyhealthPoint");
  } else if (health >= 3) {
    healthPoint3.setAnimation("healthPoint");
  }
  if (health <= 1) {
    healthPoint2.setAnimation("emptyhealthPoint");
  } else if (health >= 2) {
    healthPoint2.setAnimation("healthPoint");
  }
  if (health === 0) {
    healthPoint1.setAnimation("emptyhealthPoint");
  } else if (health >= 1) {
    healthPoint1.setAnimation("healthPoint");
  }
}
function DontLoseHealth() {
  if (health > 6) {
    health = 6;
  }
}
function LoopEnemies() {
  if (enemy1.x < -150) {
    enemy1.x = randomNumber(700,900);
  }
  if (enemy2.x < -150) {
    enemy2.x = randomNumber(900,1100);
  } else if (enemy2.x <= kirby.x) {
    enemy2.setAnimation("scarfyR");
  } else if (enemy2.x > kirby.x) {
    enemy2.setAnimation("scarfyL");
  }
  if (enemy3.x < -150) {
    enemy3.x = randomNumber(1100,1300);
  } 
  if (enemy4.x < -250) {
    enemy4.setAnimation("brontoBurtR");
    enemy4.y = kirby.y;
    enemy4.velocityX = 4;
  } else if (enemy4.x > 1000) {
    enemy4.setAnimation("brontoBurtL");
    enemy4.y = kirby.y;
    enemy4.velocityX = -4;
  }
}
function GetFood() {
  if (kirby.isTouching(food1) && health >= 6) {
    score = score + 5;
    food1.x = randomNumber(9000,9500);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  } else if (kirby.isTouching(food1)) {
    score = score + 10;
    health = 6;
    food1.x = randomNumber(9000,9500);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  }
  if (kirby.isTouching(food2) && health >= 6) {
    score = score + 1;
    food2.x = randomNumber(800,1800);
    food2.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  } else if (kirby.isTouching(food2) && health < 6) {
    score = score + 1;
    health = health + 1;
    food2.x = randomNumber(800,1800);
    food2.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  }
  if (kirby.isTouching(food3) && health >= 6) {
    score = score + 1;
    food3.x = randomNumber(800,1800);
    food3.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  } else if (kirby.isTouching(food3) && health < 6) {
    score = score + 1;
    health = health + 1;
    food3.x = randomNumber(800,1800);
    food3.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  }
  if (kirby.isTouching(food4) && health >= 6) {
    score = score + 1;
    food4.x = randomNumber(800,1800);
    food4.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  } else if (kirby.isTouching(food4) && health <6) {
    score = score + 1;
    health = health + 1;
    food4.x = randomNumber(800,1800);
    food4.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  }
  if (kirby.isTouching(food5) && health >= 6) {
    score = score + 1;
    food5.x = randomNumber(800,1800);
    food5.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  } else if (kirby.isTouching(food5) && health < 6) {
    score = score + 1;
    health = health + 1;
    food5.x = randomNumber(800,1800);
    food5.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  }
  if (kirby.isTouching(food6) && health >= 6) {
    score = score + 1;
    food6.x = randomNumber(800,1800);
    food6.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  } else if (kirby.isTouching(food6) && health <6) {
    score = score + 1;
    health = health + 1;
    food6.x = randomNumber(800,1800);
    food6.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  }
  if (kirby.isTouching(food7) && health >= 6) {
    score = score + 1;
    food7.x = randomNumber(800,1800);
    food7.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  } else if (kirby.isTouching(food7) && health <6) {
    score = score + 1;
    health = health + 1;
    food7.x = randomNumber(800,1800);
    food7.y = randomNumber(100,255);
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
  }
}
function LoopFood() {
  if (food1.x < -4000) {
    food1.x = randomNumber(9000,9500);
  }
  if (food2.x < -200) {
    food2.x = randomNumber(800,850);
  }
  if (food3.x < -200) {
    food3.x = randomNumber(800,850);
  }
  if (food4.x < -200) {
    food4.x = randomNumber(800,850);
  }
  if (food5.x < -200) {
    food5.x = randomNumber(800,850);
  }
  if (food6.x < -200) {
    food6.x = randomNumber(800,850);
  }
  if (food7.x < -200) {
    food7.x = randomNumber(800,850);
  }
}
function Invincibility() {
  if (NumberOfIFrames > 0) {
    NumberOfIFrames = NumberOfIFrames - 5;
    kirby.alpha = 0.5;
  } else if (NumberOfIFrames <= 0) {
    NumberOfIFrames = 0;
    kirby.alpha = 1;
  }
}

function draw() {
  // BACKGROUND
  // draw the ground and other background
  if (background1.x < -200) {
    background1.x = 1000;
  }
  if (background2.x < -200) {
    background2.x = 1000;
  }
  if (background3.x < -200) {
    background3.x = 1000;
  }

  // SPRITE INTERACTIONS
  // if the player touches an enemy
  // the health goes down, and the obstacle disappears
  TakeDamage();
  
  // if the player touches an enemy
  // they will be temporarily invincible
  Invincibility();

  // if the score reaches certain values, more enemies will begin to appear.
  IncreaseDifficulty();
  
  // if health is at its maximum, do not add additional health.
  DontLoseHealth();
  //if health is lost, the HUD will show it.
  LoseHealth();
  
  // if Kirby touches the food
  // the score goes up and he gains a little bit of health, the food resets
  GetFood();

  // JUMPING
  
  //if the player reaches a certain y value, they will not be able to go further up.
  if (kirby.y <= 80) {
    kirby.setAnimation("kirbyFalling");
    kirby.velocityY = 3;
  }
  
  // if the player presses the up arrow
  // start moving up
  if (keyWentDown("up") && kirby.y >= 265) {
    Jump();
  } else if (keyWentDown("up") && kirby.y < 265) {
    Float();
  }
  
  // if the player has reached the ground
  // stop moving down
  if (kirby.isTouching(background1)) {
    background1.displace(kirby);
    Walk();
  }
  if (kirby.isTouching(background2)) {
    background2.displace(kirby);
    Walk();
  }
  if (kirby.isTouching(background3)) {
    background3.displace(kirby);
    Walk();
  }

  
  //if kirby reaches the left/right edges of the screen,
  //he will stop moving.
  if (kirby.x >= 360) {
    kirby.x = 360;
  }
  if (kirby.x <= 40) {
    kirby.x = 40;
  }
  
  //if player presses the left/right arrow,
  //kirby will move left/right.
  if (keyDown("left")) {
    kirby.velocityX = -4;
  } else if (keyWentUp("left")) {
    kirby.velocityX = 0;
  }
  if (keyDown("right")) {
    kirby.velocityX = 4;
  } else if (keyWentUp("right")) {
    kirby.velocityX = 0;
  }
  

  // if the player leaves the ground, they will immediately start
  // to fall back down.
  if (kirby.y < 265) {
    Fall();
  }
  if (kirby.velocityY >= 0.5 && kirby.y < 265) {
    kirby.setAnimation("kirbyFloating");
  }
  if (kirby.velocityY >= 0.5){
    kirby.setAnimation("kirbyFalling");
  }
  

  // LOOPING
  // if the obstacle has gone off the left hand side of the screen, 
  // move it to the right hand side of the screen
  LoopEnemies();
  LoopFood();
  
  // DRAW SPRITES
  drawSprites();
  
  // SCOREBOARD
  // add scoreboard and health meter
  fill("black");
  textSize(20);
  text(score,190,390);
  // GAME OVER
  // if health runs out
  // show Game over
  if (health <= 0) {
    background1.velocityX = 0;
    background2.velocityX = 0;
    background3.velocityX = 0;
    enemy1.velocityX = 0;
    enemy2.velocityX = 0;
    enemy3.velocityX = 0;
    enemy4.velocityX = 0;
    food1.velocityX = 0;
    food2.velocityX = 0;
    food3.velocityX = 0;
    food4.velocityX = 0;
    food5.velocityX = 0;
    food6.velocityX = 0;
    food7.velocityX = 0;

    GameOverScreen.visible = true;
    fill("white");
    textSize(50);
    text("Game Over!" , 40, 200);
    textSize(30);
    text("Final Score: " + score, 70, 235);
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
