

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["21da836f-1269-4771-8b1d-66f3d60f01b5","e8a6d848-5d6a-4854-bf81-71a152106e19","5020b035-dc5c-4c52-b7e5-dcfa17055596","b45331b8-10e6-4788-a24a-ca3c8c548ea1","e58225f8-f837-4716-83a5-ff34b83f6119","a7dc8b6c-efea-42be-8f79-2f4d892e35cc","1a1ebee1-d865-4ff8-8156-643b7b891773","8b404579-f391-4140-a22b-6194e91ccc1d","4d1dcbd4-b757-47d9-987c-bef1815904dc","7932d525-88e7-4b3e-82f5-5befadb6f300","26e97d9d-5667-4a0c-8cb1-aee8a5ed7610","33002149-af4c-4d4f-a65a-efcef8e87ae8","2e9c04c5-559d-4fce-8cf1-7ee98c3318f1","cfb9d9ed-d3b2-4e2d-b5c5-ace948f8573d","e3e94155-208e-4bdb-85c3-76521f78c910","103ebd19-f210-4693-afd0-533ebe13b8e5","4394b545-a78e-4c8b-8409-42a3902d539b","b9597209-3212-4a75-bd76-6e1bfa262b0c"],"propsByKey":{"21da836f-1269-4771-8b1d-66f3d60f01b5":{"name":"bubblyClouds","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/21da836f-1269-4771-8b1d-66f3d60f01b5.png","frameSize":{"x":400,"y":320},"frameCount":1,"looping":true,"frameDelay":4,"version":"TU.GuEySkHMequqLarsg87DYCi8NGIho","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":320},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/21da836f-1269-4771-8b1d-66f3d60f01b5.png"},"e8a6d848-5d6a-4854-bf81-71a152106e19":{"name":"KirbyFloating","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":2,"looping":true,"frameDelay":3,"version":"TC.7Pa4bGbzIeGPXwj4TAm9Z0QVLnrTP","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":262},"rootRelativePath":"assets/e8a6d848-5d6a-4854-bf81-71a152106e19.png"},"5020b035-dc5c-4c52-b7e5-dcfa17055596":{"name":"StartScreenKirbyFloating","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"NTLpQIcJwTt7jcuxRetj8GHFu2frl46Y","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":131},"rootRelativePath":"assets/5020b035-dc5c-4c52-b7e5-dcfa17055596.png"},"b45331b8-10e6-4788-a24a-ca3c8c548ea1":{"name":"KirbyPuffing","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/b45331b8-10e6-4788-a24a-ca3c8c548ea1.png","frameSize":{"x":120,"y":120},"frameCount":1,"looping":true,"frameDelay":4,"version":"5KakY6fmDuJHKEYxs8XLaKrgFK18zSEi","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":120},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/b45331b8-10e6-4788-a24a-ca3c8c548ea1.png"},"e58225f8-f837-4716-83a5-ff34b83f6119":{"name":"KirbyTumbling","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":4,"looping":true,"frameDelay":3,"version":"KB2TRfK.j5D8F8h8ymdIZjNZVLSylTf4","loadedFromSource":true,"saved":true,"sourceSize":{"x":160,"y":160},"rootRelativePath":"assets/e58225f8-f837-4716-83a5-ff34b83f6119.png"},"a7dc8b6c-efea-42be-8f79-2f4d892e35cc":{"name":"KirbyTriumphant","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/a7dc8b6c-efea-42be-8f79-2f4d892e35cc.png","frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":4,"version":"ZpEdElLKsMZG0YOnVM.VXONbrPrNpDRA","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/a7dc8b6c-efea-42be-8f79-2f4d892e35cc.png"},"1a1ebee1-d865-4ff8-8156-643b7b891773":{"name":"KabulaL","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/1a1ebee1-d865-4ff8-8156-643b7b891773.png","frameSize":{"x":128,"y":176},"frameCount":1,"looping":true,"frameDelay":4,"version":"DWBukJsP_3IgUA91scYvuCBAVPAZfBxZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":176},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/1a1ebee1-d865-4ff8-8156-643b7b891773.png"},"8b404579-f391-4140-a22b-6194e91ccc1d":{"name":"KabulaR","sourceUrl":null,"frameSize":{"x":128,"y":176},"frameCount":1,"looping":true,"frameDelay":12,"version":"zw6mcg19oXmmFBA7yh.WR08.c_LRe64v","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":176},"rootRelativePath":"assets/8b404579-f391-4140-a22b-6194e91ccc1d.png"},"4d1dcbd4-b757-47d9-987c-bef1815904dc":{"name":"KabulaShot","sourceUrl":null,"frameSize":{"x":32,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"rqv7qVd2wCY7t7588p_CRnoNk39kGPQw","loadedFromSource":true,"saved":true,"sourceSize":{"x":32,"y":36},"rootRelativePath":"assets/4d1dcbd4-b757-47d9-987c-bef1815904dc.png"},"7932d525-88e7-4b3e-82f5-5befadb6f300":{"name":"EnemyHUDSprite","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/7932d525-88e7-4b3e-82f5-5befadb6f300.png","frameSize":{"x":400,"y":102},"frameCount":1,"looping":true,"frameDelay":4,"version":"NrYLrWFoVGyKiysN1TpZnsi7KiqJJNir","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":102},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/7932d525-88e7-4b3e-82f5-5befadb6f300.png"},"26e97d9d-5667-4a0c-8cb1-aee8a5ed7610":{"name":"EnemyHealthBar","sourceUrl":null,"frameSize":{"x":193,"y":28},"frameCount":1,"looping":true,"frameDelay":12,"version":"rTGFPO.lcGAbuwc4cuCt6IUHJq1oGmXL","loadedFromSource":true,"saved":true,"sourceSize":{"x":193,"y":28},"rootRelativePath":"assets/26e97d9d-5667-4a0c-8cb1-aee8a5ed7610.png"},"33002149-af4c-4d4f-a65a-efcef8e87ae8":{"name":"EnemyhealthPoint","sourceUrl":null,"frameSize":{"x":9,"y":28},"frameCount":1,"looping":true,"frameDelay":12,"version":"d33GG2nKa22e5aRYurAvKr0lbaHP4Bw4","loadedFromSource":true,"saved":true,"sourceSize":{"x":9,"y":28},"rootRelativePath":"assets/33002149-af4c-4d4f-a65a-efcef8e87ae8.png"},"2e9c04c5-559d-4fce-8cf1-7ee98c3318f1":{"name":"emptyhealthPoint","sourceUrl":null,"frameSize":{"x":28,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"zEStbHfXcIFXm4pmhA95Vys5NbVfFfAt","loadedFromSource":true,"saved":true,"sourceSize":{"x":28,"y":50},"rootRelativePath":"assets/2e9c04c5-559d-4fce-8cf1-7ee98c3318f1.png"},"cfb9d9ed-d3b2-4e2d-b5c5-ace948f8573d":{"name":"healthPoint","sourceUrl":null,"frameSize":{"x":28,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"lcQYWpBeOo5wxTFu._VwAmq.0BWu_lYS","loadedFromSource":true,"saved":true,"sourceSize":{"x":28,"y":50},"rootRelativePath":"assets/cfb9d9ed-d3b2-4e2d-b5c5-ace948f8573d.png"},"e3e94155-208e-4bdb-85c3-76521f78c910":{"name":"puff","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/e3e94155-208e-4bdb-85c3-76521f78c910.png","frameSize":{"x":70,"y":70},"frameCount":1,"looping":true,"frameDelay":4,"version":"TdDJ0DkJgTOShPN.VaW9HMFnf9OFn7jg","loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":70},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/e3e94155-208e-4bdb-85c3-76521f78c910.png"},"103ebd19-f210-4693-afd0-533ebe13b8e5":{"name":"WinScreen","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/103ebd19-f210-4693-afd0-533ebe13b8e5.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"ZnAV7CILV9h4rU2IpwfP9kjtcj8GjIx3","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/103ebd19-f210-4693-afd0-533ebe13b8e5.png"},"4394b545-a78e-4c8b-8409-42a3902d539b":{"name":"GameOverSprite","sourceUrl":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/4394b545-a78e-4c8b-8409-42a3902d539b.png","frameSize":{"x":400,"y":419},"frameCount":1,"looping":true,"frameDelay":4,"version":"LEkjXef2ODC7oSG4G0PArQ0YNAkpF22U","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":419},"rootRelativePath":"assets/v3/animations/2bXMRA-5TrguxkyijeVUTd86YWY_dLeOkyHApPBFcLw/4394b545-a78e-4c8b-8409-42a3902d539b.png"},"b9597209-3212-4a75-bd76-6e1bfa262b0c":{"name":"start_button","sourceUrl":"assets/api/v1/animation-library/gamelab/J9BTQrhVZ423u2LL0.f5j1tn.Mhq9sml/category_video_games/start_button.png","frameSize":{"x":108,"y":48},"frameCount":1,"looping":true,"frameDelay":2,"version":"J9BTQrhVZ423u2LL0.f5j1tn.Mhq9sml","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":108,"y":48},"rootRelativePath":"assets/api/v1/animation-library/gamelab/J9BTQrhVZ423u2LL0.f5j1tn.Mhq9sml/category_video_games/start_button.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// Create your variables here
var KirbyCanShoot = true;
var KabulaMovingUp = true;
var KabulaMovingDown = false;
var startGameScreen = true;
var EasyDifficulty = true;
var NormalDifficulty = false;
var HardDifficulty = false;
var MovingLeft = false;
var MovingRight = false;
var NumberOfIFrames = 200;
var health = 6;
var enemyhealth = 24;
var KirbyIsDead = false;
var YouWincoderan = false;
var GameOvercoderan = false;

// Background Sprites
var background1 = createSprite(200,160);
background1.setAnimation("bubblyClouds");
background1.visible = false;
var background2 = createSprite(600,160);
background2.setAnimation("bubblyClouds");
background2.visible = false;
var background3 = createSprite(-200,160);
background3.setAnimation("bubblyClouds");
background3.visible= false;

// Character Sprites
var Kabula = createSprite(320,100);
Kabula.setAnimation("KabulaL");
Kabula.visible = false;
var playerKirby = createSprite(60,160);
playerKirby.setAnimation("KirbyFloating");
playerKirby.setCollider("circle", 0,0,55);
playerKirby.scale = 0.9;
playerKirby.visible = false;
var DeadKirby = createSprite(playerKirby.x, playerKirby.y);
DeadKirby.setAnimation("KirbyTumbling");
DeadKirby.visible = false;

// Non-character Sprites
var shot1 = createSprite(51,600);
shot1.setAnimation("KabulaShot");
shot1.setCollider("circle");
shot1.visible = false;
var shot2 = createSprite(51,600);
shot2.setAnimation("KabulaShot");
shot2.setCollider("circle");
shot2.visible = false;
var shot3 = createSprite(51,600);
shot3.setAnimation("KabulaShot");
shot3.setCollider("circle");
shot3.visible = false;
var puff = createSprite(-200,-200);
puff.setAnimation("puff");
puff.visible = false;
var HUD = createSprite(200,350);
HUD.setAnimation("EnemyHUDSprite");
HUD.visible = false;
var healthPoint1 = createSprite(215,327);
healthPoint1.setAnimation("healthPoint");
healthPoint1.visible = false;
var healthPoint2 = createSprite(242,327);
healthPoint2.setAnimation("healthPoint");
healthPoint2.visible = false;
var healthPoint3 = createSprite(269,327);
healthPoint3.setAnimation("healthPoint");
healthPoint3.visible = false;
var healthPoint4 = createSprite(296,327);
healthPoint4.setAnimation("healthPoint");
healthPoint4.visible = false;
var healthPoint5 = createSprite(323,327);
healthPoint5.setAnimation("healthPoint");
healthPoint5.visible = false;
var healthPoint6 = createSprite(350,327);
healthPoint6.setAnimation("healthPoint");
healthPoint6.visible = false;

var BossHealthBar = createSprite(294,381);
BossHealthBar.setAnimation("EnemyHealthBar");
BossHealthBar.visible = false;
var BossHealthPoint1 = createSprite(200,381);
BossHealthPoint1.setAnimation("EnemyhealthPoint");
BossHealthPoint1.visible = false;
var BossHealthPoint2 = createSprite(208,381);
BossHealthPoint2.setAnimation("EnemyhealthPoint");
BossHealthPoint2.visible = false;
var BossHealthPoint3 = createSprite(216,381);
BossHealthPoint3.setAnimation("EnemyhealthPoint");
BossHealthPoint3.visible = false;
var BossHealthPoint4 = createSprite(224,381);
BossHealthPoint4.setAnimation("EnemyhealthPoint");
BossHealthPoint4.visible = false;
var BossHealthPoint5 = createSprite(232,381);
BossHealthPoint5.setAnimation("EnemyhealthPoint");
BossHealthPoint5.visible = false;
var BossHealthPoint6 = createSprite(240,381);
BossHealthPoint6.setAnimation("EnemyhealthPoint");
BossHealthPoint6.visible = false;
var BossHealthPoint7 = createSprite(248,381);
BossHealthPoint7.setAnimation("EnemyhealthPoint");
BossHealthPoint7.visible = false;
var BossHealthPoint8 = createSprite(256,381);
BossHealthPoint8.setAnimation("EnemyhealthPoint");
BossHealthPoint8.visible = false;
var BossHealthPoint9 = createSprite(264,381);
BossHealthPoint9.setAnimation("EnemyhealthPoint");
BossHealthPoint9.visible = false;
var BossHealthPoint10 = createSprite(272,381);
BossHealthPoint10.setAnimation("EnemyhealthPoint");
BossHealthPoint10.visible = false;
var BossHealthPoint11 = createSprite(280,381);
BossHealthPoint11.setAnimation("EnemyhealthPoint");
BossHealthPoint11.visible = false;
var BossHealthPoint12 = createSprite(288,381);
BossHealthPoint12.setAnimation("EnemyhealthPoint");
BossHealthPoint12.visible = false;
var BossHealthPoint13 = createSprite(296,381);
BossHealthPoint13.setAnimation("EnemyhealthPoint");
BossHealthPoint13.visible = false;
var BossHealthPoint14 = createSprite(304,381);
BossHealthPoint14.setAnimation("EnemyhealthPoint");
BossHealthPoint14.visible = false;
var BossHealthPoint15 = createSprite(312,381);
BossHealthPoint15.setAnimation("EnemyhealthPoint");
BossHealthPoint15.visible = false;
var BossHealthPoint16 = createSprite(320,381);
BossHealthPoint16.setAnimation("EnemyhealthPoint");
BossHealthPoint16.visible = false;
var BossHealthPoint17 = createSprite(328,381);
BossHealthPoint17.setAnimation("EnemyhealthPoint");
BossHealthPoint17.visible = false;
var BossHealthPoint18 = createSprite(336,381);
BossHealthPoint18.setAnimation("EnemyhealthPoint");
BossHealthPoint18.visible = false;
var BossHealthPoint19 = createSprite(344,381);
BossHealthPoint19.setAnimation("EnemyhealthPoint");
BossHealthPoint19.visible = false;
var BossHealthPoint20 = createSprite(352,381);
BossHealthPoint20.setAnimation("EnemyhealthPoint");
BossHealthPoint20.visible = false;
var BossHealthPoint21 = createSprite(360,381);
BossHealthPoint21.setAnimation("EnemyhealthPoint");
BossHealthPoint21.visible = false;
var BossHealthPoint22 = createSprite(368,381);
BossHealthPoint22.setAnimation("EnemyhealthPoint");
BossHealthPoint22.visible = false;
var BossHealthPoint23 = createSprite(376,381);
BossHealthPoint23.setAnimation("EnemyhealthPoint");
BossHealthPoint23.visible = false;
var BossHealthPoint24 = createSprite(384,381);
BossHealthPoint24.setAnimation("EnemyhealthPoint");
BossHealthPoint24.visible = false;

// Start Screen Sprites
var startbackground = createSprite(200,200);
startbackground.setAnimation("bubblyClouds");
startbackground.scale = 1.6;
startbackground.rotation = 25;
var button = createSprite(100,350);
button.setAnimation("start_button");
var startScreenKirby = createSprite(130,105);
startScreenKirby.setAnimation("StartScreenKirbyFloating");
startScreenKirby.scale = 1.1;
startScreenKirby.rotation = 25;
var startScreenKabula = createSprite(270,240);
startScreenKabula.setAnimation("KabulaL");
startScreenKabula.scale = 1.1;
startScreenKabula.rotation = 25;
var startScreenshot = createSprite(140,260);
startScreenshot.setAnimation("KabulaShot");
startScreenshot.scale = 1.1;
startScreenshot.rotation = 25;

// GameOverScreen Sprites 
var gameoverscreen = createSprite(200,200);
gameoverscreen.setAnimation("GameOverSprite");
gameoverscreen.visible = false;

// YouWin Sprites
var winscreen = createSprite(200,200);
winscreen.setAnimation("WinScreen");
winscreen.visible = false;
var VictoryKirby1 = createSprite(200,262);
VictoryKirby1.setAnimation("KirbyTriumphant");
VictoryKirby1.rotation = randomNumber(-5,5);
VictoryKirby1.visible = false;
var VictoryKirby2 = createSprite(300,262);
VictoryKirby2.setAnimation("KirbyTriumphant");
VictoryKirby2.rotation = randomNumber(-5,5);
VictoryKirby2.visible = false;
var VictoryKirby3 = createSprite(100,262);
VictoryKirby3.setAnimation("KirbyTriumphant");
VictoryKirby3.rotation = randomNumber(-5,5);
VictoryKirby3.visible = false;

playSound("assets/KabulaTheme.mp3", true);

function draw() {
  // BACKGROUNDS
  // draw background
  if (mousePressedOver(button)) {
    startGameScreen = false;
  }
  if (startGameScreen) {
    drawStartScreen();
  } else {
    drawPlayScreen();
  }
  MoveBackgrounds();
  LoopBackgrounds();
  // update sprites
  Boundaries();
  MoveKirby();
  if (EasyDifficulty || NormalDifficulty) {
    MoveKabula1();
  } else if (HardDifficulty) {
    MoveKabula2();
  }
  KirbyShoots();
  KabulaShoots();
  TakeDamage();
  Invincibility();
  LoseHealth();
  HitEnemy();
  EnemyLoseHealth();
  IncreaseDifficulty();
  drawSprites();
  
  if (health <= 0 && GameOvercoderan == false) {
    playerKirby.setAnimation("KirbyTumbling");
    playerKirby.setVelocity(0,0); 
    playerKirby.visible = false;
    KirbyIsDead = true;
    GameOver();
    GameOvercoderan = true;
  }
  if (KirbyIsDead) {
    playerKirby.visible = false;
    playerKirby.setVelocity(0,0);
    DeadKirby.velocityY = DeadKirby.velocityY + 0.25;
  }
  if (health <= 0 && DeadKirby.y > 500) {
    GameOverScreenText();
  }
  if (enemyhealth <= 0 && YouWincoderan == false) {
    YouWin();
    YouWincoderan = true;
  }
  if (enemyhealth <= 0) {
    YouWinScreenText();
  }
}

// Create your functions here
function drawStartScreen() {
  startbackground.visible = true;
  button.visible = true;
  startScreenKirby.visible = true;
  startScreenKabula.visible = true;
  startScreenshot.visible = true;
  Kabula.setVelocityY = 0;
  playerKirby.setVelocity(0,0);
  shot1.setVelocity(0,0);
}
function drawPlayScreen() {
  startbackground.visible = false;
  button.visible = false;
  startScreenKirby.visible = false;
  startScreenKabula.visible = false;
  startScreenshot.visible = false;
  background1.visible = true;
  background2.visible = true;
  background3.visible = true;
  playerKirby.visible = true;
  Kabula.visible = true;
  shot1.visible = true;
  puff.visible = true;
  HUD.visible = true;
  healthPoint1.visible = true;
  healthPoint2.visible = true;
  healthPoint3.visible = true;
  healthPoint4.visible = true;
  healthPoint5.visible = true;
  healthPoint6.visible = true;
  BossHealthBar.visible = true;
  BossHealthPoint1.visible = true;
  BossHealthPoint2.visible = true;
  BossHealthPoint3.visible = true;
  BossHealthPoint4.visible = true;
  BossHealthPoint5.visible = true;
  BossHealthPoint6.visible = true;
  BossHealthPoint7.visible = true;
  BossHealthPoint8.visible = true;
  BossHealthPoint9.visible = true;
  BossHealthPoint10.visible = true;
  BossHealthPoint11.visible = true;
  BossHealthPoint12.visible = true;
  BossHealthPoint13.visible = true;
  BossHealthPoint14.visible = true;
  BossHealthPoint15.visible = true;
  BossHealthPoint16.visible = true;
  BossHealthPoint17.visible = true;
  BossHealthPoint18.visible = true;
  BossHealthPoint19.visible = true;
  BossHealthPoint20.visible = true;
  BossHealthPoint21.visible = true;
  BossHealthPoint22.visible = true;
  BossHealthPoint23.visible = true;
  BossHealthPoint24.visible = true;
  shot1.velocityX = -4;
}

function Boundaries() {
  if (playerKirby.x >= 360 && health > 0) {
    playerKirby.x = 360;
  } else if (playerKirby.x >= 360 && health <= 0) {

  }
  if (playerKirby.x <= 40 && health > 0) {
    playerKirby.x = 40;
  } else if (playerKirby.x <= 40 && health <= 0) {
    
  }
  if (playerKirby.y >= 260 && health > 0) {
    playerKirby.y = 260;
  } else if (playerKirby.y >= 260 && health <= 0) {
    
  }
  if (playerKirby.y <= 40 && health >0) {
    playerKirby.y = 40;
  } else if (playerKirby.y <= 40 && health <=0) {
    
  }
}
function MoveKirby() {
  if (keyDown("left")) {
    playerKirby.velocityX = -5;
  } else if (keyWentUp("left")) {
    playerKirby.velocityX = 0;
  } else if (health <= 0){
    playerKirby.velocityX = 0;
  }
  if (keyDown("right")) {
    playerKirby.velocityX = 5;
  } else if (keyWentUp("right")) {
    playerKirby.velocityX = 0;
  } else if (health <= 0) {
    playerKirby.velocityX = 0;
  }
  if (keyDown("down")) {
    playerKirby.velocityY = 5;
  } else if (keyWentUp("down")) {
    playerKirby.velocityY = 0;
  } else if (health <= 0) {
    playerKirby.velocityY = 0;
  }
  if (keyDown("up")) {
    playerKirby.velocityY = -5;
  } else if (keyWentUp("up")) {
    playerKirby.velocityY = 0;
  } else if (health <= 0) {
    playerKirby.velocityY = 0;
  }
}
function MoveKabula1() {
  if (Kabula.y >= 215 && KabulaMovingDown && EasyDifficulty) {
    Kabula.velocityY = -3;
    KabulaMovingUp = true;
    KabulaMovingDown = false;
  } else if (Kabula.y <= 100 && KabulaMovingUp && EasyDifficulty) {
    Kabula.velocityY = 3;
    KabulaMovingUp = false;
    KabulaMovingDown = true;
  }
  if (Kabula.y >= 215 && KabulaMovingDown && NormalDifficulty) {
    Kabula.velocityY = -5;
    KabulaMovingUp = true;
    KabulaMovingDown = false;
  } else if (Kabula.y <= 60 && KabulaMovingUp && NormalDifficulty) {
    Kabula.velocityY = 5;
    KabulaMovingUp = false;
    KabulaMovingDown = true;
  }
  if (Kabula.y >= 215 && KabulaMovingDown && HardDifficulty) {
    Kabula.velocityY = -10;
    KabulaMovingUp = true;
    KabulaMovingDown = false;
  } else if (Kabula.y <= 100 && KabulaMovingUp && HardDifficulty) {
    Kabula.velocityY = 10;
    KabulaMovingUp = false;
    KabulaMovingDown = true;
  }
}
function MoveKabula2() {
  Kabula.setAnimation("KabulaL");
  Kabula.setVelocity(-7,0);
  MovingLeft = true;
  MovingRight = false;
  shot1.x = 800;
  shot1.y = 800;
  shot1.setVelocity(0,0);
  if (Kabula.x >= 600) {
    Kabula.setAnimation("KabulaL");
    Kabula.setVelocity(-7,0);
    MovingLeft = true;
    MovingRight = false;
  } else if (Kabula.x <= -200) {
    Kabula.x = 600;
    Kabula.y = randomNumber(40,200);
  }
}
function MoveBackgrounds() {
  background1.velocityX = -3;
  background2.velocityX = -3;
  background3.velocityX = -3;
}
function LoopBackgrounds() {
  if (background1.x <= -200) {
    background1.x = 600;
  } else if (background2.x <= -200) {
    background2.x = 600;
  } else if (background3.x <= -200) {
    background3.x = 600;
  }
}
function TakeDamage() {
  if (playerKirby.isTouching(Kabula) && NumberOfIFrames <= 0 && KirbyIsDead == false) {
    health = health - 1;
    playerKirby.x = 60;
    playerKirby.y = 160;
    NumberOfIFrames = 300;
    playSound("assets/category_hits/retro_game_simple_impact_1.mp3", false);
  } else if (playerKirby.isTouching(Kabula) && NumberOfIFrames > 0 && KirbyIsDead == false) {
    playerKirby.overlap(Kabula);
  }
  if (playerKirby.isTouching(shot1) && NumberOfIFrames <= 0 && KirbyIsDead == false) {
    health = health - 1;
    NumberOfIFrames = 300;
    playSound("assets/category_hits/retro_game_simple_impact_2.mp3", false);
  } else if (playerKirby.isTouching(shot1) && NumberOfIFrames > 0 && KirbyIsDead == false) {
    playerKirby.overlap(shot1);
  }
}
function KirbyShoots() {
  if (keyWentDown("space") && KirbyCanShoot) {
    playerKirby.setAnimation("KirbyPuffing");
    playSound("assets/Puffing.mp3", false);
    puff.x = playerKirby.x + playerKirby.width/2;
    puff.y = playerKirby.y;
    puff.velocityX = 17;
    KirbyCanShoot = false;
  }
  if (puff.x >= playerKirby.x + 100) {
    playerKirby.setAnimation("KirbyFloating");
    KirbyCanShoot = true;
  }
  if (puff.velocityX > 0) {
    puff.velocityX = puff.velocityX - 1;
  }
  if (puff.velocityX <= 0) {
    puff.x = -200;
    puff.y = -200;
  }
}
function KabulaShoots() {
  if (shot1.x <= -200 && EasyDifficulty && KirbyIsDead == false) {
    shot1.x = Kabula.x - Kabula.width/2;
    shot1.y = Kabula.y + 64;
    shot1.velocityX = -4;
  } else if (shot1.x <= -150 && NormalDifficulty && KirbyIsDead == false) {
    shot1.x = Kabula.x - Kabula.width/2;
    shot1.y = Kabula.y + 64;
    shot1.velocityX = -7;
  } else if (shot1.x <= -100 && HardDifficulty && KirbyIsDead == false) {
    shot1.x = Kabula.x - Kabula.width/2;
    shot1.y = Kabula.y + 64;
    shot1.velocityX = -13;
  } else if (shot1.x <= -100 && KirbyIsDead) {
    shot1.setVelocity(0,0);
    shot1.x = 600;
    shot1.y = 600;  }
}
function HitEnemy() {
  if (puff.isTouching(Kabula)) {
    enemyhealth = enemyhealth - 1;
    puff.x = 600;
    puff.y = 600;
  }
}
function LoseHealth() {
  if (health <= 5) {
    healthPoint6.setAnimation("emptyhealthPoint");
  } else if (health >= 6) {
    healthPoint6.setAnimation("healthPoint");
  }
  if (health <= 4) {
    healthPoint5.setAnimation("emptyhealthPoint");
  } else if (health >= 5) {
    healthPoint5.setAnimation("healthPoint");
  }
  if (health <= 3) {
    healthPoint4.setAnimation("emptyhealthPoint");
  } else if (health >= 4) {
    healthPoint4.setAnimation("healthPoint");
  }
  if (health <= 2) {
    healthPoint3.setAnimation("emptyhealthPoint");
  } else if (health >= 3) {
    healthPoint3.setAnimation("healthPoint");
  }
  if (health <= 1) {
    healthPoint2.setAnimation("emptyhealthPoint");
  } else if (health >= 2) {
    healthPoint2.setAnimation("healthPoint");
  }
  if (health === 0) {
    healthPoint1.setAnimation("emptyhealthPoint");
  } else if (health >= 1) {
    healthPoint1.setAnimation("healthPoint");
  } else if (health <= 0) {
    health = 0;
  }
}
function EnemyLoseHealth() {
  if (enemyhealth <= 23) {
    BossHealthPoint24.visible = false;
  } else if (enemyhealth >= 24) {
    BossHealthPoint24.visible = true;
  }
  if (enemyhealth <= 22) {
    BossHealthPoint23.visible = false;
  } else if (enemyhealth >= 23) {
    BossHealthPoint23.visible = true;
  }
  if (enemyhealth <= 21) {
    BossHealthPoint22.visible = false;
  } else if (enemyhealth >= 22) {
    BossHealthPoint22.visible = true;
  }
  if (enemyhealth <= 20) {
    BossHealthPoint21.visible = false;
  } else if (enemyhealth >= 21) {
    BossHealthPoint21.visible = true;
  }
  if (enemyhealth <= 19) {
    BossHealthPoint20.visible = false;
  } else if (enemyhealth >= 20) {
    BossHealthPoint20.visible = true;
  }
  if (enemyhealth <= 18) {
    BossHealthPoint19.visible = false;
  } else if (enemyhealth >= 19) {
    BossHealthPoint19.visible = true;
  }
  if (enemyhealth <= 17) {
    BossHealthPoint18.visible = false;
  } else if (enemyhealth >= 18) {
    BossHealthPoint18.visible = true;
  }
  if (enemyhealth <= 16) {
    BossHealthPoint17.visible = false;
  } else if (enemyhealth >= 17) {
    BossHealthPoint17.visible = true;
  }
  if (enemyhealth <= 15) {
    BossHealthPoint16.visible = false;
  } else if (enemyhealth >= 16) {
    BossHealthPoint16.visible = true;
  }
  if (enemyhealth <= 14) {
    BossHealthPoint15.visible = false;
  } else if (enemyhealth >= 15) {
    BossHealthPoint15.visible = true;
  }
  if (enemyhealth <= 13) {
    BossHealthPoint14.visible = false;
  } else if (enemyhealth >= 14) {
    BossHealthPoint14.visible = true;
  }
  if (enemyhealth <= 12) {
    BossHealthPoint13.visible = false;
  } else if (enemyhealth >= 13) {
    BossHealthPoint13.visible = true;
  }
  if (enemyhealth <= 11) {
    BossHealthPoint12.visible = false;
  } else if (enemyhealth >= 12) {
    BossHealthPoint12.visible = true;
  }
  if (enemyhealth <= 10) {
    BossHealthPoint11.visible = false;
  } else if (enemyhealth >= 11) {
    BossHealthPoint11.visible = true;
  }
  if (enemyhealth <= 9) {
    BossHealthPoint10.visible = false;
  } else if (enemyhealth >= 10) {
    BossHealthPoint10.visible = true;
  }
  if (enemyhealth <= 8) {
    BossHealthPoint9.visible = false;
  } else if (enemyhealth >= 9) {
    BossHealthPoint9.visible = true;
  }
  if (enemyhealth <= 7) {
    BossHealthPoint8.visible = false;
  } else if (enemyhealth >= 8) {
    BossHealthPoint8.visible = true;
  }
  if (enemyhealth <= 6) {
    BossHealthPoint7.visible = false;
  } else if (enemyhealth >= 7) {
    BossHealthPoint7.visible = true;
  }
  if (enemyhealth <= 5) {
    BossHealthPoint6.visible = false;
  } else if (enemyhealth >= 6) {
    BossHealthPoint6.visible = true;
  }
  if (enemyhealth <= 4) {
    BossHealthPoint5.visible = false;
  } else if (enemyhealth >= 5) {
    BossHealthPoint5.visible = true;
  }
  if (enemyhealth <= 3) {
    BossHealthPoint4.visible = false;
  } else if (enemyhealth >= 4) {
    BossHealthPoint4.visible = true;
  }
  if (enemyhealth <= 2) {
    BossHealthPoint3.visible = false;
  } else if (enemyhealth >= 3) {
    BossHealthPoint3.visible = true;
  }
  if (enemyhealth <= 1) {
    BossHealthPoint2.visible = false;
  } else if (enemyhealth >= 2) {
    BossHealthPoint2.visible = true;
  }
  if (enemyhealth <= 0) {
    BossHealthPoint1.visible = false;
  } else if (enemyhealth >= 1) {
    BossHealthPoint1.visible = true;
  }
}
function Invincibility() {
  if (NumberOfIFrames > 0) {
    NumberOfIFrames = NumberOfIFrames - 5;
    playerKirby.alpha = 0.5;
  } else if (NumberOfIFrames <= 0) {
    NumberOfIFrames = 0;
    playerKirby.alpha = 1;
  } else if (health <= 0) {
    playerKirby.visible = false;
  }
}
function IncreaseDifficulty() {
  if (enemyhealth > 16) {
    EasyDifficulty = true;
    NormalDifficulty = false;
    HardDifficulty = false;
  } else if (enemyhealth > 8) {
    EasyDifficulty = false;
    NormalDifficulty = true;
    HardDifficulty = false;
  } else if (enemyhealth > 0) {
    EasyDifficulty = false;
    NormalDifficulty = false;
    HardDifficulty = true;
  }
}
function GameOver() {
  stopSound("assets/KabulaTheme.mp3");
  playSound("assets/Lost-Life.mp3", false);
  DeadKirby.visible = true;
  DeadKirby.x = playerKirby.x;
  DeadKirby.y = playerKirby.y;
  DeadKirby.setVelocity(0,-6);
  KirbyCanShoot = false;
  Kabula.setVelocity(0,0);
  Kabula.visible = false;
  shot1.setVelocity(0,0);
  shot1.visible = false;
  puff.setVelocity(0,0);
  puff.visible = false;
  background1.visible = false;
  background2.visible = false;
  background3.visible = false;
  background1.setVelocity(0,0);
  background2.setVelocity(0,0);
  background3.setVelocity(0,0);
  HUD.visible = false;
  BossHealthBar.visible = false;
}
function GameOverScreenText() {
  gameoverscreen.visible = true;
  fill("white");
  textSize(50);
  text("Game Over!",40,200);
  textSize(30);
  text("Reset to try again.",70,235);
}
function YouWin() {
  stopSound("assets/KabulaTheme.mp3");
  playSound("assets/Major-Victory.mp3", false);
  playerKirby.setVelocity(0,0);
  playerKirby.visible = false;
  KirbyCanShoot = false;
  Kabula.setVelocity(0,0);
  Kabula.visible = false;
  shot1.setVelocity(0,0);
  shot1.visible = false;
  puff.setVelocity(0,0);
  puff.visible = false;
  background1.visible = false;
  background2.visible = false;
  background3.visible = false;
  background1.setVelocity(0,0);
  background2.setVelocity(0,0);
  background3.setVelocity(0,0);
  HUD.visible = false;
  BossHealthBar.visible = false;
  winscreen.visible = true;
  VictoryKirby1.visible = true;
  VictoryKirby2.visible = true;
  VictoryKirby3.visible = true;
}
function YouWinScreenText() {
  fill("black");
  textSize(50);
  text("You Win!",70,140);
  textSize(30);
  text("Reset to play again.",80,185);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
