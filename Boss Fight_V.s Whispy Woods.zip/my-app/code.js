

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["71518a2b-d495-4f28-ad7d-e3b636e02210","56958dcc-4a2a-411d-adcb-1197738fb3b0","306f44fd-dfa5-4e8f-899f-bfcd82575d87","82a1d2be-4a1c-4c77-8438-2f1a3de148c3","64c85f58-516c-4825-b155-93da16d4f91d","8b9929b5-874a-4534-b8b2-60ac922b142b","c030ba56-e77c-4c57-802f-d806d105dfc7","9acaadbb-40d1-4bf2-948b-3601eff5e1dd","72291551-1f6b-4a82-a0d8-15c46ceb2be3","79d171c7-ba76-45bc-a0b5-a08587f4832d","ef35a738-a0ce-40d0-99bf-96e2171746ab","95ae4c24-973a-4764-84d2-d763853f5075","b67a1d5c-9323-416a-ab87-c43d23d91225","5d0f7162-b6b6-4f5d-95b7-4f8c3cf9d5b6","05d3170f-4961-4f2d-83af-fdcd03b1b0ae","f1673847-964e-428b-ba1c-4514fdbb1a09","522ce5d8-d4c3-4b8b-810d-c392ec02b059","bc7fd04c-2c32-4f1e-a615-d12c78da88ce","ede576cb-fa8a-4774-b973-b391c2e469c6","64499d73-b743-45dd-9d69-be9f6d6802cd","732d9882-6ed1-492b-b578-75e041341ce1","bcb201c2-544f-4dae-a58b-cf5092c79774","61fc7f0f-159e-4bde-a7ea-4091e1e0ece4","5dcf9a4a-9224-497f-a7c4-8032222060b3","8e31cf98-1b6e-4cd6-9416-73506b27a1af","98818012-16ab-4fde-8ba2-1a7c67f672d5","93e63269-827d-4f65-a28f-1284e6cea4aa","2562af72-6f2b-4c19-8f9b-6da8adcd4972","32b74c57-0057-444d-81d7-0aa8d522919b","faa8eb01-4afb-4cf7-b986-7a808b8ad53b","fb3e6eb4-25b5-4fdb-a469-1c063e6d3017","90310661-2104-4842-88c0-f2d06a2d824f","d4c33e9e-1ed2-4e5d-ad9d-e4a8fb2ff515","03dfcb8d-2b8e-40a3-b1e6-4fa5719790c5","313f9866-8508-41b8-9c0c-a774b0ff3904","98df318f-cfd3-4dcc-9dc9-bee875e71af9","fb5985d4-862f-4fe3-a5ed-3cee52ca6c4d","ba51e660-d1df-49cc-ba19-2a4556832f4e","e21e33e9-21e1-4bcb-8452-bc8da780eaa8","35617ff6-4186-4350-b754-4dac018240bb","e6b9c95c-7eb6-4a59-a968-00d8f520c930"],"propsByKey":{"71518a2b-d495-4f28-ad7d-e3b636e02210":{"name":"kirbyIdleR","sourceUrl":"assets/v3/animations/APUCkshPZTmMFL1Q8BWEVyz4ak2Kyh41-MildXSmtl0/71518a2b-d495-4f28-ad7d-e3b636e02210.png","frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":4,"version":"8xKWPUWlweiHkitumBHqD33GwV65QqpD","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/v3/animations/APUCkshPZTmMFL1Q8BWEVyz4ak2Kyh41-MildXSmtl0/71518a2b-d495-4f28-ad7d-e3b636e02210.png"},"56958dcc-4a2a-411d-adcb-1197738fb3b0":{"name":"kirbyIdleL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"D0c47j08.HHDuvoXyyjCBLmQw4WruBOK","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/56958dcc-4a2a-411d-adcb-1197738fb3b0.png"},"306f44fd-dfa5-4e8f-899f-bfcd82575d87":{"name":"kirbyJumpingR","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"HZffRF5iMXAlETQdKem9Hfb_5OzeH9uS","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/306f44fd-dfa5-4e8f-899f-bfcd82575d87.png"},"82a1d2be-4a1c-4c77-8438-2f1a3de148c3":{"name":"kirbyJumpingL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"6V0WVuu8vX88bDCJ16dukaoxBjYMALKu","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/82a1d2be-4a1c-4c77-8438-2f1a3de148c3.png"},"64c85f58-516c-4825-b155-93da16d4f91d":{"name":"kirbyFallingR","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"72xbzB_C.GeHIhI0kDygQIfsDgZ14E90","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/64c85f58-516c-4825-b155-93da16d4f91d.png"},"8b9929b5-874a-4534-b8b2-60ac922b142b":{"name":"kirbyFallingL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":1,"looping":true,"frameDelay":12,"version":"K9FPUdj5ziRCZejDl55yX4ZtsG2GyFs_","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":80},"rootRelativePath":"assets/8b9929b5-874a-4534-b8b2-60ac922b142b.png"},"c030ba56-e77c-4c57-802f-d806d105dfc7":{"name":"kirbyFloatingR","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"P1kh4yEeZZmb49NccA5hnQZ1Utt9JaBB","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":131},"rootRelativePath":"assets/c030ba56-e77c-4c57-802f-d806d105dfc7.png"},"9acaadbb-40d1-4bf2-948b-3601eff5e1dd":{"name":"kirbyFloatingL","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"inPC6cg9ov2x3yalNVkQEtt.QbiHEoCB","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":131},"rootRelativePath":"assets/9acaadbb-40d1-4bf2-948b-3601eff5e1dd.png"},"72291551-1f6b-4a82-a0d8-15c46ceb2be3":{"name":"kirbyFloatingDownR","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"rauqks7wQyYthwmocSDUA7yIBREYsNlf","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":131},"rootRelativePath":"assets/72291551-1f6b-4a82-a0d8-15c46ceb2be3.png"},"79d171c7-ba76-45bc-a0b5-a08587f4832d":{"name":"kirbyFloatingDownL","sourceUrl":null,"frameSize":{"x":120,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"tbiEIQTSpda1zMiAcgPteME4DXtYNiVS","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":131},"rootRelativePath":"assets/79d171c7-ba76-45bc-a0b5-a08587f4832d.png"},"ef35a738-a0ce-40d0-99bf-96e2171746ab":{"name":"kirbyWalkingR","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":4,"looping":true,"frameDelay":4,"version":"IFlyyPHT5p_TUv2HV_ARLznatElTZZwT","loadedFromSource":true,"saved":true,"sourceSize":{"x":160,"y":160},"rootRelativePath":"assets/ef35a738-a0ce-40d0-99bf-96e2171746ab.png"},"95ae4c24-973a-4764-84d2-d763853f5075":{"name":"kirbyWalkingL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":4,"looping":true,"frameDelay":4,"version":"_P1jOeslZtYmscZi8xgjujd.K1rr4WhC","loadedFromSource":true,"saved":true,"sourceSize":{"x":160,"y":160},"rootRelativePath":"assets/95ae4c24-973a-4764-84d2-d763853f5075.png"},"b67a1d5c-9323-416a-ab87-c43d23d91225":{"name":"kirbyInhalingR","sourceUrl":null,"frameSize":{"x":80,"y":110},"frameCount":1,"looping":true,"frameDelay":12,"version":"9wlef_PtgVrUSJt9cBrnjugpyGirZ1jg","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":110},"rootRelativePath":"assets/b67a1d5c-9323-416a-ab87-c43d23d91225.png"},"5d0f7162-b6b6-4f5d-95b7-4f8c3cf9d5b6":{"name":"kirbyInhalingL","sourceUrl":null,"frameSize":{"x":80,"y":110},"frameCount":1,"looping":true,"frameDelay":12,"version":"1qjI5yCZTumQUBDwA7obv78_FSOeGyUI","loadedFromSource":true,"saved":true,"sourceSize":{"x":80,"y":110},"rootRelativePath":"assets/5d0f7162-b6b6-4f5d-95b7-4f8c3cf9d5b6.png"},"05d3170f-4961-4f2d-83af-fdcd03b1b0ae":{"name":"Apple","sourceUrl":null,"frameSize":{"x":64,"y":64},"frameCount":4,"looping":true,"frameDelay":12,"version":"rTMmEWeKc6VgKi1DIvDKmbg5ntL_m83J","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/05d3170f-4961-4f2d-83af-fdcd03b1b0ae.png"},"f1673847-964e-428b-ba1c-4514fdbb1a09":{"name":"WhispyWoods","sourceUrl":null,"frameSize":{"x":400,"y":353},"frameCount":1,"looping":true,"frameDelay":12,"version":"s5DA4XKG74jCZLFyER3UyeKUGfnmC029","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":353},"rootRelativePath":"assets/f1673847-964e-428b-ba1c-4514fdbb1a09.png"},"522ce5d8-d4c3-4b8b-810d-c392ec02b059":{"name":"WhispysFace","sourceUrl":null,"frameSize":{"x":101,"y":162},"frameCount":19,"looping":true,"frameDelay":1,"version":"CrzmPRKgbda0AOwvTR.RSgNpMjyxVeEd","loadedFromSource":true,"saved":true,"sourceSize":{"x":606,"y":648},"rootRelativePath":"assets/522ce5d8-d4c3-4b8b-810d-c392ec02b059.png"},"bc7fd04c-2c32-4f1e-a615-d12c78da88ce":{"name":"EnemyHUDSprite","sourceUrl":null,"frameSize":{"x":400,"y":70},"frameCount":1,"looping":true,"frameDelay":12,"version":"y80x4ik5EKH_6NAO1LV4ioSaXh1Fq3M0","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":70},"rootRelativePath":"assets/bc7fd04c-2c32-4f1e-a615-d12c78da88ce.png"},"ede576cb-fa8a-4774-b973-b391c2e469c6":{"name":"healthPoint","sourceUrl":null,"frameSize":{"x":26,"y":46},"frameCount":1,"looping":true,"frameDelay":12,"version":"33nv2H_O5kSMz10eSL2kv.2q080upkFv","loadedFromSource":true,"saved":true,"sourceSize":{"x":26,"y":46},"rootRelativePath":"assets/ede576cb-fa8a-4774-b973-b391c2e469c6.png"},"64499d73-b743-45dd-9d69-be9f6d6802cd":{"name":"healthPointshrunk","sourceUrl":null,"frameSize":{"x":27,"y":29},"frameCount":1,"looping":true,"frameDelay":12,"version":"uYQ30ITxeP9BjDL5RXKu7DV_WxNh8xDm","loadedFromSource":true,"saved":true,"sourceSize":{"x":27,"y":29},"rootRelativePath":"assets/64499d73-b743-45dd-9d69-be9f6d6802cd.png"},"732d9882-6ed1-492b-b578-75e041341ce1":{"name":"emptyhealthPoint","sourceUrl":"assets/v3/animations/APUCkshPZTmMFL1Q8BWEVyz4ak2Kyh41-MildXSmtl0/732d9882-6ed1-492b-b578-75e041341ce1.png","frameSize":{"x":26,"y":46},"frameCount":1,"looping":true,"frameDelay":4,"version":"GonbY6JYEBtxamygqewNOrloAFgoVn26","loadedFromSource":true,"saved":true,"sourceSize":{"x":26,"y":46},"rootRelativePath":"assets/v3/animations/APUCkshPZTmMFL1Q8BWEVyz4ak2Kyh41-MildXSmtl0/732d9882-6ed1-492b-b578-75e041341ce1.png"},"bcb201c2-544f-4dae-a58b-cf5092c79774":{"name":"emptyhealthPointshrunk","sourceUrl":null,"frameSize":{"x":26,"y":28},"frameCount":1,"looping":true,"frameDelay":12,"version":"xguId5LGmpNjORuukr8U4DV0SW4F.iKb","loadedFromSource":true,"saved":true,"sourceSize":{"x":26,"y":28},"rootRelativePath":"assets/bcb201c2-544f-4dae-a58b-cf5092c79774.png"},"61fc7f0f-159e-4bde-a7ea-4091e1e0ece4":{"name":"EnemyhealthPoint","sourceUrl":null,"frameSize":{"x":9,"y":24},"frameCount":1,"looping":true,"frameDelay":12,"version":"0gDztN0J3o_hY6CfzH1iYjrRFWknWxCd","loadedFromSource":true,"saved":true,"sourceSize":{"x":9,"y":24},"rootRelativePath":"assets/61fc7f0f-159e-4bde-a7ea-4091e1e0ece4.png"},"5dcf9a4a-9224-497f-a7c4-8032222060b3":{"name":"EnemyhealthPointshrunk","sourceUrl":null,"frameSize":{"x":9,"y":16},"frameCount":1,"looping":true,"frameDelay":12,"version":"Vi_NXr6GElmwEv8gp0xF4oyis2UkvsFr","loadedFromSource":true,"saved":true,"sourceSize":{"x":9,"y":16},"rootRelativePath":"assets/5dcf9a4a-9224-497f-a7c4-8032222060b3.png"},"8e31cf98-1b6e-4cd6-9416-73506b27a1af":{"name":"emptyEnemyhealthBar","sourceUrl":null,"frameSize":{"x":171,"y":16},"frameCount":1,"looping":true,"frameDelay":12,"version":"yjHcYka_EH7Q.NxdsrsJq8WtzULfnEKO","loadedFromSource":true,"saved":true,"sourceSize":{"x":171,"y":16},"rootRelativePath":"assets/8e31cf98-1b6e-4cd6-9416-73506b27a1af.png"},"98818012-16ab-4fde-8ba2-1a7c67f672d5":{"name":"StarShotR","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":4,"looping":true,"frameDelay":2,"version":"cDMU7s3pA9..s.ad2gf9Z1.w6RCSTSuN","loadedFromSource":true,"saved":true,"sourceSize":{"x":160,"y":160},"rootRelativePath":"assets/98818012-16ab-4fde-8ba2-1a7c67f672d5.png"},"93e63269-827d-4f65-a28f-1284e6cea4aa":{"name":"StarShotL","sourceUrl":null,"frameSize":{"x":80,"y":80},"frameCount":4,"looping":true,"frameDelay":2,"version":"iv2uaC96Aq1bGbslSp7tjcMNwjhMXkSg","loadedFromSource":true,"saved":true,"sourceSize":{"x":160,"y":160},"rootRelativePath":"assets/93e63269-827d-4f65-a28f-1284e6cea4aa.png"},"2562af72-6f2b-4c19-8f9b-6da8adcd4972":{"name":"dustParticle","sourceUrl":null,"frameSize":{"x":12,"y":24},"frameCount":1,"looping":true,"frameDelay":12,"version":"Mb0NmulBPFgrPIdErqfSLOduVXsHB4cn","loadedFromSource":true,"saved":true,"sourceSize":{"x":12,"y":24},"rootRelativePath":"assets/2562af72-6f2b-4c19-8f9b-6da8adcd4972.png"},"32b74c57-0057-444d-81d7-0aa8d522919b":{"name":"GameOverSprite","sourceUrl":null,"frameSize":{"x":400,"y":419},"frameCount":1,"looping":true,"frameDelay":12,"version":"DOS1R5t3dWtKhHEOyJftChImz2GGx5h6","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":419},"rootRelativePath":"assets/32b74c57-0057-444d-81d7-0aa8d522919b.png"},"faa8eb01-4afb-4cf7-b986-7a808b8ad53b":{"name":"FullkirbyIdleR","sourceUrl":null,"frameSize":{"x":120,"y":115},"frameCount":1,"looping":true,"frameDelay":12,"version":"5r9LSRKuZ0K9PeFtLOa3fsvYJQebxkjS","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":115},"rootRelativePath":"assets/faa8eb01-4afb-4cf7-b986-7a808b8ad53b.png"},"fb3e6eb4-25b5-4fdb-a469-1c063e6d3017":{"name":"FullkirbyIdleL","sourceUrl":null,"frameSize":{"x":120,"y":115},"frameCount":1,"looping":true,"frameDelay":12,"version":"KuL5LSgeq7oZFtVXEozVMvazsvED.wIL","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":115},"rootRelativePath":"assets/fb3e6eb4-25b5-4fdb-a469-1c063e6d3017.png"},"90310661-2104-4842-88c0-f2d06a2d824f":{"name":"FullkirbyWalkingR","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":4,"looping":true,"frameDelay":4,"version":"Z0XYiTiqiwISfpJ1xxabH_N0nZ4z_Su.","loadedFromSource":true,"saved":true,"sourceSize":{"x":240,"y":240},"rootRelativePath":"assets/90310661-2104-4842-88c0-f2d06a2d824f.png"},"d4c33e9e-1ed2-4e5d-ad9d-e4a8fb2ff515":{"name":"FullkirbyJumpingR","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":1,"looping":true,"frameDelay":12,"version":"qRsiIOa30bxMvC4IauIgWCq59TIVfdbl","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":120},"rootRelativePath":"assets/d4c33e9e-1ed2-4e5d-ad9d-e4a8fb2ff515.png"},"03dfcb8d-2b8e-40a3-b1e6-4fa5719790c5":{"name":"FullkirbyWalkingL","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":4,"looping":true,"frameDelay":4,"version":"Bz142oxPHtkKDFM4RZzyj2CDfgB4ROsU","loadedFromSource":true,"saved":true,"sourceSize":{"x":240,"y":240},"rootRelativePath":"assets/03dfcb8d-2b8e-40a3-b1e6-4fa5719790c5.png"},"313f9866-8508-41b8-9c0c-a774b0ff3904":{"name":"FullkirbyJumpingL","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":1,"looping":true,"frameDelay":12,"version":"B6HtvX.dxGWA_bzOaIiP7kZ25bQ7dhn7","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":120},"rootRelativePath":"assets/313f9866-8508-41b8-9c0c-a774b0ff3904.png"},"98df318f-cfd3-4dcc-9dc9-bee875e71af9":{"name":"FullkirbySpittingR","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":4,"looping":false,"frameDelay":4,"version":".jSuudEnJn6rBQBwMUgV8xd8JEyL1cRr","loadedFromSource":true,"saved":true,"sourceSize":{"x":240,"y":240},"rootRelativePath":"assets/98df318f-cfd3-4dcc-9dc9-bee875e71af9.png"},"fb5985d4-862f-4fe3-a5ed-3cee52ca6c4d":{"name":"FullkirbySpittingL","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":4,"looping":false,"frameDelay":5,"version":"7zAkilcrtB6gEgJdcoJ1rSispTUCqyyJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":240,"y":240},"rootRelativePath":"assets/fb5985d4-862f-4fe3-a5ed-3cee52ca6c4d.png"},"ba51e660-d1df-49cc-ba19-2a4556832f4e":{"name":"FullkirbySpittingAirR","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":3,"looping":false,"frameDelay":5,"version":"hhZQPK9LFzbGd6nqn0TLpvbz7m5NENJD","loadedFromSource":true,"saved":true,"sourceSize":{"x":240,"y":240},"rootRelativePath":"assets/ba51e660-d1df-49cc-ba19-2a4556832f4e.png"},"e21e33e9-21e1-4bcb-8452-bc8da780eaa8":{"name":"FullkirbySpittingAirL","sourceUrl":null,"frameSize":{"x":120,"y":120},"frameCount":3,"looping":false,"frameDelay":5,"version":"5hIAE31ovrnMm1oulnDqy76eQt9eU2xk","loadedFromSource":true,"saved":true,"sourceSize":{"x":240,"y":240},"rootRelativePath":"assets/e21e33e9-21e1-4bcb-8452-bc8da780eaa8.png"},"35617ff6-4186-4350-b754-4dac018240bb":{"name":"WinScreen","sourceUrl":null,"frameSize":{"x":432,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"Isfq.TuCJmx7DLrpqZ25FnHeK5oDywPY","loadedFromSource":true,"saved":true,"sourceSize":{"x":432,"y":400},"rootRelativePath":"assets/35617ff6-4186-4350-b754-4dac018240bb.png"},"e6b9c95c-7eb6-4a59-a968-00d8f520c930":{"name":"HitSprite","sourceUrl":null,"frameSize":{"x":64,"y":64},"frameCount":3,"looping":false,"frameDelay":2,"version":"KJzcpXscMtr6B2xM115tQicrrULXoVAU","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/e6b9c95c-7eb6-4a59-a968-00d8f520c930.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// Background Sprite
var background1 = createSprite(200,154);
background1.setAnimation("WhispyWoods");
background1.setCollider("rectangle", 0, 155, 400, 50);

// Non-character Sprites
var apple = createSprite(randomNumber(70,240),60);
apple.setAnimation("Apple");
apple.setCollider("circle");
apple.bounciness = 0.5;
var shot = createSprite(-90,600);
shot.setAnimation("StarShotR");
shot.setCollider("circle");
shot.visible = false;
var particle1 = createSprite(-600,-600);
particle1.setAnimation("dustParticle");
var particle2 = createSprite(-600,-600);
particle2.setAnimation("dustParticle");
var particle3 = createSprite(-600,-600);
particle3.setAnimation("dustParticle");

// Character Sprites
var kirby = createSprite(60,265);
kirby.setAnimation("kirbyIdleR");
kirby.setCollider("circle", 0, 0, 30);
var WhispyWoods = createSprite(303,185);
WhispyWoods.setAnimation("WhispysFace");

// Nonvisible Variables
var InTheAir = false;
var OnTheGround = true;
var IsFloating = false;
var FacingRight = true;
var FacingLeft = false;
var CanInhale = true;
var IsInhaling = false;
var IsNotInhaling = true;
var IsFull = false;
var IsNotFull = true;
var CanShoot = false;

// Visible Variables
var health = 6;
var enemyhealth = 28;

// HUD Sprites
var HUD = createSprite(200,365);
HUD.setAnimation("EnemyHUDSprite");
var healthPoint1 = createSprite(214,351);
healthPoint1.setAnimation("healthPointshrunk");
var healthPoint2 = createSprite(241,351);
healthPoint2.setAnimation("healthPointshrunk");
var healthPoint3 = createSprite(268,351);
healthPoint3.setAnimation("healthPointshrunk");
var healthPoint4 = createSprite(295,351);
healthPoint4.setAnimation("healthPointshrunk");
var healthPoint5 = createSprite(322,351);
healthPoint5.setAnimation("healthPointshrunk");
var healthPoint6 = createSprite(349,351);
healthPoint6.setAnimation("healthPointshrunk");

var BossHealthBar = createSprite(280,384);
BossHealthBar.setAnimation("emptyEnemyhealthBar");
var BossHealthPoint1 = createSprite(200,384);
BossHealthPoint1.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint2 = createSprite(206,384);
BossHealthPoint2.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint3 = createSprite(212,384);
BossHealthPoint3.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint4 = createSprite(218,384);
BossHealthPoint4.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint5 = createSprite(224,384);
BossHealthPoint5.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint6 = createSprite(230,384);
BossHealthPoint6.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint7 = createSprite(236,384);
BossHealthPoint7.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint8 = createSprite(242,384);
BossHealthPoint8.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint9 = createSprite(248,384);
BossHealthPoint9.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint10 = createSprite(254,384);
BossHealthPoint10.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint11 = createSprite(260,384);
BossHealthPoint11.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint12 = createSprite(266,384);
BossHealthPoint12.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint13 = createSprite(272,384);
BossHealthPoint13.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint14 = createSprite(278,384);
BossHealthPoint14.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint15 = createSprite(284,384);
BossHealthPoint15.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint16 = createSprite(290,384);
BossHealthPoint16.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint17 = createSprite(296,384);
BossHealthPoint17.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint18 = createSprite(302,384);
BossHealthPoint18.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint19 = createSprite(308,384);
BossHealthPoint19.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint20 = createSprite(314,384);
BossHealthPoint20.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint21 = createSprite(320,384);
BossHealthPoint21.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint22 = createSprite(326,384);
BossHealthPoint22.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint23 = createSprite(332,384);
BossHealthPoint23.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint24 = createSprite(338,384);
BossHealthPoint24.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint25 = createSprite(344,384);
BossHealthPoint25.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint26 = createSprite(350,384);
BossHealthPoint26.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint27 = createSprite(356,384);
BossHealthPoint27.setAnimation("EnemyhealthPointshrunk");
var BossHealthPoint28 = createSprite(362,384);
BossHealthPoint28.setAnimation("EnemyhealthPointshrunk");

var gameoverscreen = createSprite(200,200);
gameoverscreen.setAnimation("GameOverSprite");
gameoverscreen.visible = false;

var winscreen = createSprite(200,200);
winscreen.setAnimation("WinScreen");
winscreen.visible = false;

// Functions
function PhysicsEngine() {
  if (kirby.y >= 265) {
    OnTheGround = true;
    InTheAir = false;
  }
  if (kirby.y < 265) {
    InTheAir = true;
    OnTheGround = false;
  }
}
function StayStill() {
  if (kirby.y >= 265) {
    kirby.velocityY = 0;
    kirby.y = 265;
    IsFloating = false;
  }
  if (kirby.x <= 40) {
    kirby.x = 40;
  } else if (kirby.x >= 239) {
    kirby.x = 239;
  }
  if (kirby.velocityX === 0 && OnTheGround && FacingRight && IsNotFull) {
    kirby.setAnimation("kirbyIdleR");
    CanInhale = true;
  } else if (kirby.velocityX === 0 && OnTheGround && FacingLeft && IsNotFull) {
    kirby.setAnimation("kirbyIdleL");
    CanInhale = true;
  } else if (kirby.velocityX === 0 && OnTheGround && FacingRight && IsFull) {
    kirby.setAnimation("FullkirbyIdleR");
  } else if (kirby.velocityX === 0 && OnTheGround && FacingLeft && IsFull) {
    kirby.setAnimation("FullkirbyIdleL");
  }
}
function Move() {
  if (keyDown("left") && OnTheGround && IsNotFull) {
    kirby.setAnimation("kirbyWalkingL");
    kirby.velocityX = -5;
    FacingLeft = true;
    FacingRight = false;
    CanInhale = true;
  } else if (keyWentUp("left") && OnTheGround && IsNotFull) {
    kirby.setAnimation("kirbyIdleL");
    kirby.velocityX = 0;
    FacingLeft = true;
    FacingRight = false;
    CanInhale = true;
  } else if (keyDown("left") && OnTheGround && IsFull) {
    kirby.setAnimation("FullkirbyWalkingL");
    kirby.velocityX = -5;
    FacingLeft = true;
    FacingRight = false;
  } else if (keyWentUp("left") && OnTheGround && IsFull) {
    kirby.setAnimation("FullkirbyIdleL");
    kirby.velocityX = 0;
    FacingLeft = true;
    FacingRight = false;
  }
  if (keyDown("right") && OnTheGround && IsNotFull) {
    kirby.setAnimation("kirbyWalkingR");
    kirby.velocityX = 5;
    FacingRight = true;
    FacingLeft = false;
    CanInhale = true;
  } else if (keyWentUp("right") && OnTheGround && IsNotFull) {
    kirby.setAnimation("kirbyIdleR");
    kirby.velocityX = 0;
    FacingRight = true;
    FacingLeft = false;
    CanInhale = true;
  } else if (keyDown("right") && OnTheGround && IsFull) {
    kirby.setAnimation("FullkirbyWalkingR");
    kirby.velocityX = 5;
    FacingLeft = false;
    FacingRight = true;
  } else if (keyWentUp("right") && OnTheGround && IsFull) {
    kirby.setAnimation("FullkirbyIdleR");
    kirby.velocityX = 0;
    FacingLeft = false;
    FacingRight = true;
  }
  if (keyDown("left") && InTheAir) {
    kirby.velocityX = -5;
    FacingLeft = true;
    FacingRight = false;
  } else if (keyWentUp("left") && InTheAir) {
    kirby.velocityX = 0;
    FacingLeft = true;
    FacingRight = false;
  }
  if (keyDown("right") && InTheAir) {
    kirby.velocityX = 5;
    FacingRight = true;
    FacingLeft = false;
  } else if (keyWentUp("right") && InTheAir) {
    kirby.velocityX = 0;
    FacingRight = true;
    FacingLeft = false;
  }
  if (keyWentDown("down") && InTheAir && IsFloating) {
    kirby.velocityY = 1;
    IsFloating = false;
    CanInhale = true;
  }
}
function Float() {
  if (keyWentDown("up") && InTheAir && FacingRight) {
    kirby.velocityY = -9;
    kirby.setAnimation("kirbyFloatingR");
    IsFloating = true;
    CanInhale = false;
  } else if (keyWentDown("up") && InTheAir && FacingLeft) {
    kirby.velocityY = -9;
    kirby.setAnimation("kirbyFloatingL");
    IsFloating = true;
    CanInhale = false;
  }
}
function FloatDown() {
  if (kirby.velocityY >= 0.5 && InTheAir && IsFloating && FacingRight) {
    kirby.setAnimation("kirbyFloatingDownR");
  }
  if (kirby.velocityY >= 0.5 && InTheAir && IsFloating && FacingLeft) {
    kirby.setAnimation("kirbyFloatingDownL");
  }
}
function Fall() {
  if (InTheAir && FacingRight) {
    kirby.velocityY = kirby.velocityY + 0.75;
  } else if (InTheAir && FacingLeft) {
    kirby.velocityY = kirby.velocityY + 0.75;
  }
  if (kirby.velocityY > 0.5 && InTheAir && FacingRight && IsNotFull) {
    kirby.setAnimation("kirbyFallingR");
  } else if (kirby.velocityY > 0.5 && InTheAir && FacingRight && IsFull) {
    kirby.setAnimation("FullkirbyJumpingR");
  }
  if (kirby.velocityY > 0.5 && InTheAir && FacingLeft && IsNotFull) {
    kirby.setAnimation("kirbyFallingL");
  } else if (kirby.velocityY > 0.5 && InTheAir && FacingLeft && IsFull) {
    kirby.setAnimation("FullkirbyJumpingL");
  }
  if (kirby.y <= 80) {
    kirby.velocityY = 2;
  }
}
function Jump() {
  if (keyWentDown("up") && OnTheGround && FacingRight && IsNotFull) {
    kirby.velocityY = -11;
    kirby.setAnimation("kirbyJumpingR");
  } else if (keyWentDown("up") && OnTheGround && FacingRight && IsFull) {
    kirby.velocityY = -11;
    kirby.setAnimation("FullkirbyJumpingR");
  }
  if (keyWentDown("up") && OnTheGround && FacingLeft && IsNotFull) {
    kirby.velocityY = -11;
    kirby.setAnimation("kirbyJumpingL");
  } else if (keyWentDown("up") && OnTheGround && FacingLeft && IsFull) {
    kirby.velocityY = -11;
    kirby.setAnimation("FullkirbyJumpingL");
  }
}
function TakeDamage() {
  if (kirby.isTouching(apple) && IsNotInhaling) {
    health = health - 1;
    apple.destroy();
    apple = createSprite(randomNumber(70,210),60);
    apple.setAnimation("Apple");
    apple.setCollider("circle");
  }
}
function ShotProperties() {
  if (shot.x > 260) {
    enemyhealth = enemyhealth - 2;
    shot.destroy();
    shot = createSprite(-90,600);
    shot.velocityX = 0;
    shot.setAnimation("StarShotR");
    shot.setCollider("circle");
    shot.visible = false;
  } else if (shot.x < -100) {
    shot.destroy();
    shot = createSprite(-90,600);
    shot.velocityX = 0;
    shot.setAnimation("StarShotR");
    shot.setCollider("circle");
    shot.visible = false;
  }
}
function Inhale() {
  if (keyDown("space") && CanInhale && FacingRight) {
    kirby.setAnimation("kirbyInhalingR");
    kirby.setCollider("rectangle", 0, 0, 40, 60, 0);
    kirby.velocityX = 0;
    particle1.visible = true;
    particle2.visible = true;
    particle3.visible = true;
    particle1.x = kirby.x + 80;
    particle1.y = kirby.y - 20;
    particle2.x = kirby.x + 70;
    particle3.x = kirby.x + 80;
    particle3.y = kirby.y + 20;
    IsInhaling = true;
  } else if (keyWentUp("space") && FacingRight) {
    kirby.setAnimation("kirbyIdleR");
    kirby.setCollider("circle");
    particle1.visible = false;
    particle1.x = -600;
    particle1.y = -600;
    particle1.setVelocity(0,0);
    particle2.visible = false;
    particle2.x = -600;
    particle2.y = -600;
    particle2.velocityX = 0;
    particle3.visible = false;
    particle3.x = -600;
    particle3.y = -600;
    particle3.setVelocity(0,0);
    IsInhaling = false;
  } else if (keyWentUp("space") && InTheAir && FacingRight) {
    kirby.setAnimation("kirbyFallingR");
    kirby.setCollider("circle");
    IsInhaling = false;
  }
  if (keyDown("space") && FacingLeft && CanInhale) {
    kirby.setAnimation("kirbyInhalingL");
    kirby.setCollider("rectangle", 0, 0, 40, 60, 0);
    kirby.velocityX = 0;
    particle1.visible = true;
    particle2.visible = true;
    particle3.visible = true;
    particle1.x = kirby.x - 80;
    particle1.y = kirby.y - 20;
    particle2.x = kirby.x - 70;
    particle3.x = kirby.x - 80;
    particle3.y = kirby.y + 20;
    IsInhaling = true;
  } else if (keyWentUp("space") && FacingLeft) {
    kirby.setAnimation("kirbyIdleL");
    kirby.setCollider("circle");
    particle1.visible = false;
    particle1.x = -600;
    particle1.y = -600;
    particle1.setVelocity(0,0);
    particle2.visible = false;
    particle2.x = -600;
    particle2.y = -600;
    particle2.velocityX = 0;
    particle3.visible = false;
    particle3.x = -600;
    particle3.y = -600;
    particle3.setVelocity(0,0);
    IsInhaling = false;
  } else if (keyWentUp("space") && InTheAir && FacingLeft) {
    kirby.setAnimation("kirbyFallingL");
    kirby.setCollider("circle");
    IsInhaling = false;
  }
}
function SuckUp() {
  if (apple.isTouching(particle1) && apple.x > kirby.x && IsInhaling) {
    apple.bounciness = 0.5;
    apple.velocityX = apple.velocityX - 1;
  } else if (apple.isTouching(particle1) && apple.x < kirby.x && IsInhaling) {
    apple.bounciness = 0.5;
    apple.velocityX = apple.velocityX + 1;
  } else if (apple.isTouching(particle2) && apple.x > kirby.x && IsInhaling) {
    apple.bounciness = 0.5;
    apple.velocityX = apple.velocityX - 1;
  } else if (apple.isTouching(particle2) && apple.x < kirby.x && IsInhaling) {
    apple.bounciness = 0.5;
    apple.velocityX = apple.velocityX + 1;
  } else if (apple.isTouching(particle3) && apple.x > kirby.x && IsInhaling) {
    apple.bounciness = 0.5;
    apple.velocityX = apple.velocityX - 1;
  } else if (apple.isTouching(particle3) && apple.x < kirby.x && IsInhaling) {
    apple.bounciness = 0.5;
    apple.velocityX = apple.velocityX + 1;
  }
  if (apple.isTouching(kirby) && IsInhaling) {
    apple.destroy();
    apple = createSprite(-600,800);
    apple.setAnimation("Apple");
    apple.setCollider("circle");
    apple.bounciness = 0.5;
    particle1.visible = false;
    particle1.x = -600;
    particle1.y = -600;
    particle1.setVelocity(0,0);
    particle2.visible = false;
    particle2.x = -600;
    particle2.y = -600;
    particle2.velocityX = 0;
    particle3.visible = false;
    particle3.x = -600;
    particle3.y = -600;
    particle3.setVelocity(0,0);
    CanInhale = false;
    IsInhaling = false;
    IsNotInhaling = true;
    IsFull = true;
    IsNotFull = false;
    CanShoot = true;
  }
}
function SpitOut(){
  if (keyWentDown("space") && IsFull && CanShoot && FacingRight) {
    kirby.setAnimation("FullkirbySpittingR");
    shot.velocityX = 12;
    shot.x = kirby.x + kirby.width/2;
    shot.y = kirby.y;
    shot.visible = true;
    IsFull = false;
    IsNotFull = true;
    CanShoot = false;
    CanInhale = true;
  } else if (keyWentDown("space") && IsFull && CanShoot && FacingLeft) {
    kirby.setAnimation("FullkirbySpittingL");
    shot.velocityX = -12;
    shot.x = kirby.x - kirby.width/2;
    shot.y = kirby.y;
    shot.visible = true;
    IsFull = false;
    IsNotFull = true;
    CanShoot = false;
    CanInhale = true;
  } 
}
function LoseHealth() {
  if (health <= 5) {
    healthPoint6.setAnimation("emptyhealthPointshrunk");
  } else if (health >= 6) {
    healthPoint6.setAnimation("healthPointshrunk");
  }
  if (health <= 4) {
    healthPoint5.setAnimation("emptyhealthPointshrunk");
  } else if (health >= 5) {
    healthPoint5.setAnimation("healthPointshrunk");
  }
  if (health <= 3) {
    healthPoint4.setAnimation("emptyhealthPointshrunk");
  } else if (health >= 4) {
    healthPoint4.setAnimation("healthPointshrunk");
  }
  if (health <= 2) {
    healthPoint3.setAnimation("emptyhealthPointshrunk");
  } else if (health >= 3) {
    healthPoint3.setAnimation("healthPointshrunk");
  }
  if (health <= 1) {
    healthPoint2.setAnimation("emptyhealthPointshrunk");
  } else if (health >= 2) {
    healthPoint2.setAnimation("healthPointshrunk");
  }
  if (health === 0) {
    healthPoint1.setAnimation("emptyhealthPointshrunk");
  } else if (health >= 1) {
    healthPoint1.setAnimation("healthPointshrunk");
  }
}
function AppleProperties() {
  if (apple.y < 265) {
    apple.velocityY = apple.velocityY + 0.3;
  } else if (apple.isTouching(background1)){
    apple.bounceOff(background1);
    apple.velocityX = -2;
  }
  if (apple.x < -100) {
    apple.x = randomNumber(70,340);
    apple.y = 60;
    apple.velocityX = 0;
  }
}
function EnemyLoseHealth() {
  if (enemyhealth <= 27) {
    BossHealthPoint28.visible = false;
  } else if (enemyhealth >= 28) {
    BossHealthPoint28.visible = true;
  }
  if (enemyhealth <= 26) {
    BossHealthPoint27.visible = false;
  } else if (enemyhealth >= 27) {
    BossHealthPoint27.visible = true;
  }
  if (enemyhealth <= 25) {
    BossHealthPoint26.visible = false;
  } else if (enemyhealth >= 26) {
    BossHealthPoint26.visible = true;
  }
  if (enemyhealth <= 24) {
    BossHealthPoint25.visible = false;
  } else if (enemyhealth >= 25) {
    BossHealthPoint25.visible = true;
  }
  if (enemyhealth <= 23) {
    BossHealthPoint24.visible = false;
  } else if (enemyhealth >= 24) {
    BossHealthPoint24.visible = true;
  }
  if (enemyhealth <= 22) {
    BossHealthPoint23.visible = false;
  } else if (enemyhealth >= 23) {
    BossHealthPoint23.visible = true;
  }
  if (enemyhealth <= 21) {
    BossHealthPoint22.visible = false;
  } else if (enemyhealth >= 22) {
    BossHealthPoint22.visible = true;
  }
  if (enemyhealth <= 20) {
    BossHealthPoint21.visible = false;
  } else if (enemyhealth >= 21) {
    BossHealthPoint21.visible = true;
  }
  if (enemyhealth <= 19) {
    BossHealthPoint20.visible = false;
  } else if (enemyhealth >= 20) {
    BossHealthPoint20.visible = true;
  }
  if (enemyhealth <= 18) {
    BossHealthPoint19.visible = false;
  } else if (enemyhealth >= 19) {
    BossHealthPoint19.visible = true;
  }
  if (enemyhealth <= 17) {
    BossHealthPoint18.visible = false;
  } else if (enemyhealth >= 18) {
    BossHealthPoint18.visible = true;
  }
  if (enemyhealth <= 16) {
    BossHealthPoint17.visible = false;
  } else if (enemyhealth >= 17) {
    BossHealthPoint17.visible = true;
  }
  if (enemyhealth <= 15) {
    BossHealthPoint16.visible = false;
  } else if (enemyhealth >= 16) {
    BossHealthPoint16.visible = true;
  }
  if (enemyhealth <= 14) {
    BossHealthPoint15.visible = false;
  } else if (enemyhealth >= 15) {
    BossHealthPoint15.visible = true;
  }
  if (enemyhealth <= 13) {
    BossHealthPoint14.visible = false;
  } else if (enemyhealth >= 14) {
    BossHealthPoint14.visible = true;
  }
  if (enemyhealth <= 12) {
    BossHealthPoint13.visible = false;
  } else if (enemyhealth >= 13) {
    BossHealthPoint13.visible = true;
  }
  if (enemyhealth <= 11) {
    BossHealthPoint12.visible = false;
  } else if (enemyhealth >= 12) {
    BossHealthPoint12.visible = true;
  }
  if (enemyhealth <= 10) {
    BossHealthPoint11.visible = false;
  } else if (enemyhealth >= 11) {
    BossHealthPoint11.visible = true;
  }
  if (enemyhealth <= 9) {
    BossHealthPoint10.visible = false;
  } else if (enemyhealth >= 10) {
    BossHealthPoint10.visible = true;
  }
  if (enemyhealth <= 8) {
    BossHealthPoint9.visible = false;
  } else if (enemyhealth >= 9) {
    BossHealthPoint9.visible = true;
  }
  if (enemyhealth <= 7) {
    BossHealthPoint8.visible = false;
  } else if (enemyhealth >= 8) {
    BossHealthPoint8.visible = true;
  }
  if (enemyhealth <= 6) {
    BossHealthPoint7.visible = false;
  } else if (enemyhealth >= 7) {
    BossHealthPoint7.visible = true;
  }
  if (enemyhealth <= 5) {
    BossHealthPoint6.visible = false;
  } else if (enemyhealth >= 6) {
    BossHealthPoint6.visible = true;
  }
  if (enemyhealth <= 4) {
    BossHealthPoint5.visible = false;
  } else if (enemyhealth >= 5) {
    BossHealthPoint5.visible = true;
  }
  if (enemyhealth <= 3) {
    BossHealthPoint4.visible = false;
  } else if (enemyhealth >= 4) {
    BossHealthPoint4.visible = true;
  }
  if (enemyhealth <= 2) {
    BossHealthPoint3.visible = false;
  } else if (enemyhealth >= 3) {
    BossHealthPoint3.visible = true;
  }
  if (enemyhealth <= 1) {
    BossHealthPoint2.visible = false;
  } else if (enemyhealth >= 2) {
    BossHealthPoint2.visible = true;
  }
  if (enemyhealth <= 0) {
    BossHealthPoint1.visible = false;
  } else if (enemyhealth >= 1) {
    BossHealthPoint1.visible = true;
  }
}
function GameOver() {
  kirby.setVelocity(0,0);
  apple.setVelocity(0,0);
  apple.visible = false;
  shot.setVelocity(0,0);
  gameoverscreen.visible = true;
  fill("white");
  textSize(50);
  text("Game Over!", 40, 200);
  textSize(30);
  text("Reset to try again.", 70, 235);
}
function YouWin() {
  kirby.setVelocity(0,0);
  apple.setVelocity(0,0);
  apple.visible = false;
  shot.setVelocity(0,0);
  winscreen.visible = true;
  fill("black");
  textSize(50);
  text("You Win!", 40, 200);
  textSize(30);
  text("Reset to play again.", 70, 235);
}

function draw() {
  PhysicsEngine();
  Move();
  StayStill();
  Fall();
  Float();
  Jump();
  FloatDown();
  Inhale();
  SuckUp();
  SpitOut();
  AppleProperties;
  ShotProperties();
  TakeDamage();
  LoseHealth();
  EnemyLoseHealth();
  
  drawSprites();
  AppleProperties();
  if (health <= 0) {
    GameOver();
  }
  if (enemyhealth <= 0) {
    YouWin();
  }
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
